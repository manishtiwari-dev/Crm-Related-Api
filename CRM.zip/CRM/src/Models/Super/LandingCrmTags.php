<?php

namespace Modules\CRM\Models\Super;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LandingCrmTags extends Model
{
    use HasFactory;
    protected $primaryKey = 'tags_id';
    protected $guarded = [
        'tags_id',

    ];
    public function getTable()
    {
        return config('dbtable.landing_crm_tags');
    }
}
