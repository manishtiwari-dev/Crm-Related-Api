<?php

namespace Modules\CRM\Models\Super;


use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\CRM\Models\Super\LandingCrmLeadContact;
use Modules\CRM\Models\Super\LandingCrmLeadSocialLink;
use Modules\CRM\Models\Super\LandingCrmLeadStatus;
use Modules\CRM\Models\Super\LandingCrmLeadFollowUpHistory;
use Modules\CRM\Models\Super\LandingCrmAgent;
use Modules\CRM\Models\Super\LandingCrmIndustry;
use Modules\CRM\Models\CRMCustomer;

class LandingCrmLead extends Model
{
    use HasFactory;
    protected $primaryKey = 'lead_id';
    protected $guarded = [
        'lead_id',

    ];

    public function getTable()
    {
        return config('dbtable.landing_crm_lead');
    }

    public function crm_lead_contact()
    {
        return $this->hasMany(LandingCrmLeadContact::class, 'lead_id', 'lead_id');
    }

    public function crm_lead_soclink()
    {
        return $this->hasMany(LandingCrmLeadSocialLink::class, 'lead_id', 'lead_id');
    }



    public function crm_lead_source()
    {
        return $this->belongsTo(LandingCrmLeadSource::class, 'source_id', 'source_id');
    }

    public function crm_lead_industry()
    {
        return $this->belongsTo(LandingCrmIndustry::class, 'industry_id', 'industry_id');
    }

    public function crm_lead_agent()
    {
        return $this->belongsTo(LandingCrmAgent::class, 'agent_id', 'agent_id');
    }

    public function crm_lead_followup()
    {
        return $this->hasOne(LandingCrmLeadFollowUp::class, 'lead_id', 'lead_id');
    }

    public function crm_lead_followup_history()
    {
        return $this->hasMany(LandingCrmLeadFollowUpHistory::class, 'lead_id', 'lead_id');
    }

    // public function crmcustomer()
    // {
    //     return $this->belongsTo(CRMCustomer::class, 'contact_email', 'email');
    // }

    public function crmLeadtag()
    {
        return $this->belongsToMany(LandingCrmLeadToTag::class,  'lead_id', 'lead_id');
    }


    public function crm_social()
    {
        return $this->belongsTo(LandingCrmLeadSocialLink::class, 'lead_id', ' lead_id');
    }


    public function crmLeadToTag()
    {
        return $this->belongsToMany(LandingCrmTags::class, config('dbtable.landing_crm_lead_to_tags'), 'lead_id', 'tags_id');
    }
}
