<?php

namespace Modules\CRM\Models\Super;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;




class LandingCrmLeadStatus extends Model
{
    use HasFactory;
    protected $primaryKey = 'status_id';
    protected $fillable = [
        'status_name',
        'sort_order',
        'status',
    ];
    public function getTable()
    {
        return config('dbtable.landing_crm_lead_status');
    }
}
