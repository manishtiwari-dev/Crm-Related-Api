<?php

namespace Modules\CRM\Models\Super;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LandingCrmNotes extends Model
{
    use HasFactory;
    protected $primaryKey = 'note_id';
    protected $fillable = [
        'lead_id',
        'note_details',
        'note_visibility',
        'created_by',
    ];
    public function getTable()
    {
        return config('dbtable.landing_crm_notes');
    }
}
