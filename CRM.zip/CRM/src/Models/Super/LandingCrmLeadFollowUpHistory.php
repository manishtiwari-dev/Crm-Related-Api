<?php

namespace Modules\CRM\Models\Super;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LandingCrmLeadFollowUpHistory extends Model
{
    use HasFactory;
    protected $primaryKey = 'id';
    protected $fillable = [
        'followup_id',
        'followup_at',
        'followup_status',
        'followup_note',
    ];
    public function getTable()
    {
        return config('dbtable.landing_crm_lead_followup_history');
    }

    public $timestamps = false;


    public function crmLeadfollowup()
    {
        return $this->belongsTo(LandingCrmLeadFollowUp::class, 'followup_id', 'followup_id');
    }

    public function crmLeadStatus()
    {
        return $this->belongsTo(LandingCrmLeadStatus::class, 'followup_status', 'status_id');
    }
}
