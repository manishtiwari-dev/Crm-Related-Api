<?php

namespace Modules\CRM\Models\Super;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LandingCrmIndustry extends Model
{
    use HasFactory;
    protected $primaryKey = 'industry_id';
    protected $fillable = [
        'industry_name',
        'status',
    ];
    public function getTable()
    {
        return config('dbtable.landing_crm_industry');
    }
}
