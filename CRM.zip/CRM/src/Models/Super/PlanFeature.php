<?php

namespace Modules\CRM\Models\Super;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\CRM\Models\Super\PlanToFeature;
use Modules\CRM\Models\Super\FeatureIndustry;

class PlanFeature extends Model
{
    use HasFactory;
  
    // protected $table = "sub_plan_feature";
   // protected $table = "website_setting";
    protected $primaryKey = 'feature_id';
    protected $guarded = [
           'feature_id',
    ];

    public function getTable()
    {
        return config('dbtable.sub_plan_feature');
    }

    public function plan_to_feature()
    {
        return $this->hasOne(PlanToFeature::class, 'feature_id', 'feature_id');
    }
   
    public function feature_to_industry()
    {
        return $this->hasMany(FeatureIndustry::class, 'feature_id', 'feature_id');
    }
  
}
