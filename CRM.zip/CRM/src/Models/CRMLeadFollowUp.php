<?php
namespace Modules\CRM\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\CRM\Models\CRMLeadFollowUpHistory;
use App\Models\User;
use App\Models\Order;
use Modules\CRM\Models\Quotation;

class CRMLeadFollowUp extends Model
{
    use HasFactory;
    protected $primaryKey = 'followup_id';
    protected $fillable = [
        'lead_id',
        'source',
        'source_id',
        'followup_status',
        'last_followup',
        'next_followup',
        'followup_nos',
        'followup_tag',
        'created_at',
    ];
    public function getTable()
    {
        return config('dbtable.crm_lead_followup');
    }

    public function crm_lead_followup_history()
    {
        return $this->hasMany(CRMLeadFollowUpHistory::class, 'followup_id', 'followup_id');
    }

    public $timestamps = false;
    

    public function crmLeadStatus()
    {
      return $this->belongsTo(CRMLeadStatus::class, 'followup_status' , 'status_id');

    }

    public function User(){

        return $this->belongsTo(User::class, 'created_by' , 'id');

    }

     public function enquiry(){
        return $this->belongsTo(Enquiry::class, 'source_id' , 'enquiry_id');
    }

    public function order(){
        return $this->belongsTo(Order::class, 'source_id' , 'order_id');
    }


    public function quotation(){
        return $this->belongsTo(CRMQuotation::class, 'source_id' , 'quotation_id');
    }

    public function crm_lead(){
        return $this->belongsTo(CRMLead::class, 'lead_id' , 'lead_id');
    }
}
