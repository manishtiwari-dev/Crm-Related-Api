<?php
namespace Modules\CRM\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\CRM\Models\SubCRMTickets;
use App\Models\User;

class SubCRMTicketsReplies extends Model
{
    use HasFactory;

    protected $primaryKey = 'id';
    protected $guarded = [
        'id',
        
    ];
  
    public function getTable()
    {
        return config('dbtable.crm_ticket_replies');
    }
    

 
//    public function user(){

//         return $this->belongsTo(User::class,'user_id');
//     }
    
    public function ticket_details()
    {
        return $this->belongsTo(SubCRMTickets::class,'ticket_id','id');
    }

}
