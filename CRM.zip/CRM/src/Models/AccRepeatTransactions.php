<?php

namespace Modules\CRM\Models;


use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\CRM\Models\AppAccounts;

class AccRepeatTransactions extends Model
{
    use HasFactory;
    protected $primaryKey = 'id';
    protected $guarded = [
        'id',

    ];
    public function getTable()
    {
        return config('dbtable.acc_repeating_transactions');
    }

    public function Accounts()
    {

        return $this->belongsTo(AppAccounts::class, 'account_id', 'id');
    }
}
