<?php

namespace Modules\CRM\Models;


use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\CRM\Models\AppAccounts;
use App\Models\PaymentMethods;
use Modules\CRM\Models\CRMCustomer;



class AppTransactions extends Model
{
    use HasFactory;
    protected $primaryKey = 'id';
    protected $guarded = [
        'id',

    ];
    public function getTable()
    {
        return config('dbtable.app_transactions');
    }

    public function Accounts()
    {

        return $this->belongsTo(AppAccounts::class, 'account_id', 'id');
    }

    public function paymentMethod()
    {

        return $this->belongsTo(PaymentMethods::class, 'payment_method_id', 'payment_method_id');
    }

    public function customerDetails()
    {
        return $this->belongsTo(CRMCustomer::class, 'payer_payee_id', 'customer_id');
    }
}
