<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Modules\CRM\Http\Controllers\CRMLeadController;
use Modules\CRM\Http\Controllers\CRMIndustryController;
use Modules\CRM\Http\Controllers\CRMAgentController;
use Modules\CRM\Http\Controllers\CRMSocialLinkController;
use Modules\CRM\Http\Controllers\CRMLeadContactController;
use Modules\CRM\Http\Controllers\CRMLeadFollowUpController;
use Modules\CRM\Http\Controllers\CRMLeadStatusController;
use Modules\CRM\Http\Controllers\CRMLeadSourceController;
use Modules\CRM\Http\Controllers\CRMCustomerController;
use Modules\CRM\Http\Controllers\CRMQuotationController;
use Modules\CRM\Http\Controllers\CRMSettingPaymentTermsController;
use Modules\CRM\Http\Controllers\CRMSettingTaxController;
use Modules\CRM\Http\Controllers\CRMSettingTaxGroupController;
use Modules\CRM\Http\Controllers\WebEnquiryController;
use Modules\CRM\Http\Controllers\Super\CRMTicketController;
use Modules\CRM\Http\Controllers\Super\EnquiryController;
use Modules\CRM\Http\Controllers\LeadAgentController;
use Modules\CRM\Http\Controllers\CRMLeadsControllers;
use Modules\CRM\Http\Controllers\ExpensesController;
use Modules\CRM\Http\Controllers\IncomeController;
use Modules\CRM\Http\Controllers\SettingController;
use Modules\CRM\Http\Controllers\InvoiceController;
use Modules\CRM\Http\Controllers\TaxTypeController;
use Modules\CRM\Http\Controllers\TransactionController;


/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/


Route::group(['middleware' => ['ApiTokenCheck'], 'prefix' => "api/"], function () {

    //CRM lead API

    Route::group(['prefix' => 'lead'], function () {
        Route::post('/', [CRMLeadController::class, 'index']);
        Route::post('/import/file', [CRMLeadController::class, 'import_file']);
        Route::post('/status/tab', [CRMLeadController::class, 'status_tab']);
        Route::post('/view', [CRMLeadController::class, 'view']);
        Route::post('/followup/store', [CRMLeadController::class, 'lead_followup_store']);
        Route::post('/changeStatus', [CRMLeadController::class, 'changeStatus']);
    });

    //crm leads
    Route::group(['prefix' => 'leads'], function () {
        Route::post('/', [CRMLeadsControllers::class, 'index']);
        Route::post('/store', [CRMLeadsControllers::class, 'store']);
        Route::post('/update', [CRMLeadsControllers::class, 'update']);
        Route::post('/create', [CRMLeadsControllers::class, 'create']);
        Route::post('/show', [CRMLeadsControllers::class, 'show']);
        Route::post('/edit', [CRMLeadsControllers::class, 'edit']);
        Route::post('/status', [CRMLeadsControllers::class, 'changeStatus']);
        Route::post('/destroy', [CRMLeadsControllers::class, 'destroy']);
        Route::post('/agentsupdate', [CRMLeadsControllers::class, 'agentsupdate']);
        Route::post('/lead-import-create', [CRMLeadsControllers::class, 'leadImportCreate']);
        Route::post('/crm-lead-import-store', [CRMLeadsControllers::class, 'leadImportStore']);
    });



    // end CRM lead API

    //CRM lead Industry API

    Route::group(['prefix' => 'lead_industry'], function () {
        Route::post('/', [CRMIndustryController::class, 'index']);
        //Route::post('/create', [CRMIndustryController::class,'create']);
        Route::post('/store', [CRMIndustryController::class, 'store']);
        Route::post('/edit', [CRMIndustryController::class, 'edit']);
        Route::post('/update', [CRMIndustryController::class, 'update']);
        Route::post('/changeStatus', [CRMIndustryController::class, 'changeStatus']);
    });

    //end CRM lead Industry

    //CRM lead_agent API
    Route::group(['prefix' => 'lead_agent'], function () {
        Route::post('/', [CRMAgentController::class, 'index']);
        Route::post('/store', [CRMAgentController::class, 'store']);
        Route::post('/edit', [CRMAgentController::class, 'edit']);
        Route::post('/update', [CRMAgentController::class, 'update']);
        //Route::post('/changeStatus', [CRMAgentController::class,'changeStatus']);
    });
    //end CRM lead_agent API

    // CRM lead_sociallink API
    Route::group(['prefix' => 'lead_sociallink'], function () {
        Route::post('/', [CRMSocialLinkController::class, 'index']);
        Route::post('/store', [CRMSocialLinkController::class, 'store']);
        Route::post('/edit', [CRMSocialLinkController::class, 'edit']);
        Route::post('/update', [CRMSocialLinkController::class, 'update']);
        //Route::post('/changeStatus', [CRMSocialLinkController::class,'changeStatus']);
    });
    //end CRM lead_sociallink API

    //CRM lead_contact
    Route::group(['prefix' => 'lead_contact'], function () {
        Route::post('/', [CRMLeadContactController::class, 'index']);
        Route::post('/store', [CRMLeadContactController::class, 'store']);
        Route::post('/edit', [CRMLeadContactController::class, 'edit']);
        Route::post('/update', [CRMLeadContactController::class, 'update']);
        //Route::post('/changeStatus', [CRMLeadContactController::class,'changeStatus']);
    });
    //end CRM lead_contact API

    // CRM lead_followup API
    Route::group(['prefix' => 'lead_followup'], function () {
        Route::post('/', [CRMLeadFollowUpController::class, 'index']);
        Route::post('/store', [CRMLeadFollowUpController::class, 'store']);
        Route::post('/edit', [CRMLeadFollowUpController::class, 'edit']);
        Route::post('/update', [CRMLeadFollowUpController::class, 'update']);
        Route::post('/changeStatus', [CRMLeadFollowUpController::class, 'changeStatus']);

        Route::post('/client-followUp', [CRMLeadFollowUpController::class, 'followUpStore']);
        Route::post('/get-followUp', [CRMLeadFollowUpController::class, 'GetFollowup']);
        Route::post('/get-followUphistory', [CRMLeadFollowUpController::class, 'followUphistory']);
        Route::post('/note-store', [CRMLeadFollowUpController::class, 'NoteStore']);
        Route::post('/lead-tag-update', [CRMLeadFollowUpController::class, 'LeadTagUpdate']);
    });
    //end CRM lead_followup API


    //CRM lead_status API
    Route::group(['prefix' => 'lead_status'], function () {
        Route::post('/', [CRMLeadStatusController::class, 'index']);
        Route::post('/store', [CRMLeadStatusController::class, 'store']);
        Route::post('/edit', [CRMLeadStatusController::class, 'edit']);
        Route::post('/update', [CRMLeadStatusController::class, 'update']);
        Route::post('/changeStatus', [CRMLeadStatusController::class, 'changeStatus']);
    });
    //end CRM lead_status API

    //CRM lead_source
    Route::group(['prefix' => 'lead_source'], function () {
        Route::post('/', [CRMLeadSourceController::class, 'index']);
        Route::post('/store', [CRMLeadSourceController::class, 'store']);
        Route::post('/edit', [CRMLeadSourceController::class, 'edit']);
        Route::post('/update', [CRMLeadSourceController::class, 'update']);
        Route::post('/changeStatus', [CRMLeadSourceController::class, 'changeStatus']);
        Route::post('/deptUser', [CRMLeadSourceController::class, 'deptUser']);
        Route::post('/agentStore', [CRMLeadSourceController::class, 'agentStore']);
        Route::post('/agent-edit', [CRMLeadSourceController::class, 'agentEdit']);
        Route::post('/agent-update', [CRMLeadSourceController::class, 'agentUpdate']);
        Route::post('/lead-sortorder', [CRMLeadSourceController::class, 'sortOrder']);
        Route::post('/lead-status-color', [CRMLeadSourceController::class, 'statusColor']);
    });
    //end CRM lead source API


    Route::group(['prefix' => 'lead_agent'], function () {
        Route::post('/deptUser', [LeadAgentController::class, 'deptUser']);
        Route::post('/agentStore', [LeadAgentController::class, 'agentStore']);
        Route::post('/agent-edit', [LeadAgentController::class, 'agentEdit']);
        Route::post('/agent-update', [LeadAgentController::class, 'agentUpdate']);
        Route::post('/change-status', [LeadAgentController::class, 'changeStatus']);

        Route::post('/tags-store', [LeadAgentController::class, 'tagStore']);
        Route::post('/tags-edit', [LeadAgentController::class, 'tagsEdit']);
        Route::post('/tags-update', [LeadAgentController::class, 'tagsUpdate']);
        Route::post('/change-tag-status', [LeadAgentController::class, 'changeTagStatus']);
    });

    //CRM crm_customer API
    Route::group(['prefix' => 'crm_customer'], function () {
        Route::post('/', [CRMCustomerController::class, 'index']);
        Route::post('/store', [CRMCustomerController::class, 'store']);
        Route::post('/edit', [CRMCustomerController::class, 'edit']);
        Route::post('/update', [CRMCustomerController::class, 'update']);
        Route::post('/view', [CRMCustomerController::class, 'view']);
        Route::post('/create', [CRMCustomerController::class, 'create']);
        Route::post('/isdefaultupdate', [CRMCustomerController::class, 'isdefaultupdate']);
        Route::post('/changeStatus', [CRMCustomerController::class, 'changeStatus']);
        Route::post('/get-customer-details', [CRMCustomerController::class, 'customerDetails']);
    });
    //end CRM crm_customer API

    //CRM crm_quotation API
    Route::group(['prefix' => 'crm_quotation'], function () {
        Route::post('/', [CRMQuotationController::class, 'index']);
        Route::post('/store', [CRMQuotationController::class, 'store']);
        Route::post('/edit', [CRMQuotationController::class, 'edit']);
        Route::post('/update', [CRMQuotationController::class, 'update']);
        Route::post('/create', [CRMQuotationController::class, 'create']);
        Route::post('/customer/alldata', [CRMQuotationController::class, 'customeralldata']);
        Route::post('/contactsdata', [CRMQuotationController::class, 'ContactsInformation']);
        Route::post('/changeStatus', [CRMQuotationController::class, 'changeStatus']);
        Route::post('/SearchSuggestion', [CRMQuotationController::class, 'SearchSuggestion']);
        Route::post('/quotationdetailspdf', [CRMQuotationController::class, 'quotationdetailspdf']);
        Route::post('/send-reminder', [CRMQuotationController::class, 'sendReminder']);

        Route::post('search-item-detail', [CRMQuotationController::class, 'SearchItemDetail'])->name('SearchItemDetail');
    });
    //end CRM crm_quotation API


    //CRM crm_setting_payment_terms API
    Route::group(['prefix' => 'crm_setting_payment_terms'], function () {
        Route::post('/', [CRMSettingPaymentTermsController::class, 'index']);
        Route::post('/store', [CRMSettingPaymentTermsController::class, 'store']);
        Route::post('/edit', [CRMSettingPaymentTermsController::class, 'edit']);
        Route::post('/update', [CRMSettingPaymentTermsController::class, 'update']);
    });

    //end CRM crm_setting_payment_terms API

    //CRM crm_setting_tax API
    Route::group(['prefix' => 'crm_setting_tax'], function () {
        Route::post('/', [CRMSettingTaxController::class, 'index']);
        Route::post('/update', [CRMSettingTaxController::class, 'update']);
        Route::post('/changeStatus', [CRMSettingTaxController::class, 'changeStatus']);
        Route::post('/edit', [CRMSettingTaxController::class, 'edit']);
        Route::post('/destroy', [CRMSettingTaxController::class, 'destroy']);
    });
    //end CRM crm_setting_tax API


    //CRM crm_setting_tax_group API
    Route::group(['prefix' => 'setting_tax_group'], function () {
        Route::post('/create', [CRMSettingTaxGroupController::class, 'create']);
        Route::post('/store', [CRMSettingTaxGroupController::class, 'store']);
        Route::post('/edit', [CRMSettingTaxGroupController::class, 'edit']);
        Route::post('/update', [CRMSettingTaxGroupController::class, 'update']);
        Route::post('/destroy', [CRMSettingTaxGroupController::class, 'destroy']);
    });

    //end CRM crm_setting_tax_group API


    //CRM crm_setting_tax_type API
    Route::group(['prefix' => 'setting_tax_type'], function () {
        Route::post('/create', [TaxTypeController::class, 'create']);
        Route::post('/store', [TaxTypeController::class, 'store']);
        Route::post('/edit', [TaxTypeController::class, 'edit']);
        Route::post('/update', [TaxTypeController::class, 'update']);
        Route::post('/destroy', [TaxTypeController::class, 'destroy']);
    });

    //end CRM crm_setting_tax_group API




    //Web Enquiry prefix

    Route::group(['prefix' => 'enquiry'], function () {
        Route::post('/', [WebEnquiryController::class, 'index']);
        Route::post('/store', [WebEnquiryController::class, 'store']);
        Route::post('/edit', [WebEnquiryController::class, 'edit']);
        Route::post('/update', [WebEnquiryController::class, 'update']);
        Route::post('/destroy', [WebEnquiryController::class, 'destroy']);
        Route::post('/changeStatus', [WebEnquiryController::class, 'changeStatus']);
        Route::post('/enquiry_details', [WebEnquiryController::class, 'enquiry_details']);
    });

    //end enquiry

    //super Webenquiry

    Route::group(['prefix' => 'superEnquiry'], function () {
        Route::post('/', [EnquiryController::class, 'index']);
        Route::post('/store', [EnquiryController::class, 'store']);
        Route::post('/edit', [EnquiryController::class, 'edit']);
        Route::post('/update', [EnquiryController::class, 'update']);
        Route::post('/destroy', [EnquiryController::class, 'destroy']);
        Route::post('/changeStatus', [EnquiryController::class, 'changeStatus']);
    });

    //Crm Tickets prefix        
    Route::group(['prefix' => 'tickets'], function () {
        Route::post('/', [CRMTicketController::class, 'index']);
        Route::post('/store', [CRMTicketController::class, 'store']);
        Route::post('/create', [CRMTicketController::class, 'create']);
        Route::post('/changeStatus', [CRMTicketController::class, 'changeStatus']);
        Route::post('/details', [CRMTicketController::class, 'details']);
        Route::post('/send_reply', [CRMTicketController::class, 'send_reply']);
    });
    //end prefix


    //crm expenses

    Route::group(['prefix' => 'expenses'], function () {
        Route::post('/', [ExpensesController::class, 'index']);
        Route::post('/store', [ExpensesController::class, 'store']);
        Route::post('/create', [ExpensesController::class, 'create']);
        Route::post('/edit', [ExpensesController::class, 'edit']);
        Route::post('/update', [ExpensesController::class, 'update']);
        Route::post('/destroy', [ExpensesController::class, 'destroy']);
    });

    //crm income
    Route::group(['prefix' => 'income'], function () {
        Route::post('/', [IncomeController::class, 'index']);
        Route::post('/store', [IncomeController::class, 'store']);
        Route::post('/create', [IncomeController::class, 'create']);
        Route::post('/edit', [IncomeController::class, 'edit']);
        Route::post('/update', [IncomeController::class, 'update']);
        Route::post('/destroy', [IncomeController::class, 'destroy']);
    });



    //crm expanse setting
    Route::group(['prefix' => 'settings'], function () {
        Route::post('/', [SettingController::class, 'index']);
        Route::post('/store', [SettingController::class, 'store']);
        Route::post('/create', [SettingController::class, 'create']);
        Route::post('/edit', [SettingController::class, 'edit']);
        Route::post('/update', [SettingController::class, 'update']);
        Route::post('/destroy', [SettingController::class, 'destroy']);
        Route::post('/account-store', [SettingController::class, 'accountStore']);
        Route::post('/account-edit', [SettingController::class, 'accountEdit']);
        Route::post('/account-update', [SettingController::class, 'updateAccount']);
        Route::post('/account-destroy', [SettingController::class, 'destroyAccount']);
        Route::post('/changeStatus', [SettingController::class, 'changeStatus']);
        Route::post('/changeAccStatus', [SettingController::class, 'changeAccStatus']);




    });


    //sales invoices
    Route::group(['prefix' => 'invoices'], function () {
        Route::post('/', [InvoiceController::class, 'index']);
        Route::post('/store', [InvoiceController::class, 'store']);
        Route::post('/create', [InvoiceController::class, 'create']);
        Route::post('/edit', [InvoiceController::class, 'edit']);
        Route::post('/update', [InvoiceController::class, 'update']);
        Route::post('/destroy', [InvoiceController::class, 'destroy']);
        Route::post('/invoicesdetailspdf', [InvoiceController::class, 'InvoiceDetailsPDF']);
        Route::post('/changeStatus', [InvoiceController::class, 'changeStatus']);
        Route::post('/changeDate', [InvoiceController::class, 'changeDate']);

        
    });

    //sales invoices
    Route::group(['prefix' => 'transaction'], function () {
        Route::post('/', [TransactionController::class, 'index']);
        Route::post('/store', [TransactionController::class, 'store']);
        Route::post('/create', [TransactionController::class, 'create']);
        Route::post('/edit', [TransactionController::class, 'edit']);
        Route::post('/update', [TransactionController::class, 'update']);
        Route::post('/destroy', [TransactionController::class, 'destroy']);
        Route::post('/calendar', [TransactionController::class, 'calendar']);
        Route::post('/export', [TransactionController::class, 'export']);
    });
});
