<?php

namespace Modules\CRM\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use ApiHelper;
use App\Models\Currency;
use App\Models\Country;

use Modules\CRM\Models\CRMCustomer;
use Modules\CRM\Models\CRMCustomerAddress;
use Modules\CRM\Models\CRMLead;
use Modules\CRM\Models\CRMLeadContact;
use Modules\CRM\Models\CRMQuotation;
use Modules\CRM\Models\CRMQuotationItem;
use Modules\Ecommerce\Models\Product;
use Modules\CRM\Models\CRMCustomerContact;
use Modules\CRM\Models\CRMSettingPaymentTerms;
use Modules\CRM\Models\CRMSettingTax;
use Modules\CRM\Models\CRMSettingTaxGroup;
use Modules\Ecommerce\Models\Services\ProductServices;
use DateTime;
use Carbon\Carbon;
use App\Models\Super\SuperAppSetting;
use App\Models\User;
use Exception;
use Modules\CRM\Jobs\QuoteReminderJob;
use Modules\CRM\Models\CRMLeadFollowUp;
use Modules\CRM\Models\CRMSettingTaxPercentage;
use Modules\CRM\Models\CRMSettingTaxType;
use Modules\CRM\Models\QuoteReminderHistory;
use Modules\Ecommerce\Models\ProductsOptionsValues;

class CRMQuotationController extends Controller
{
    public $page = 'quotation';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';
    public $app_share_portal_link = 'app_share_portal_link';


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    public function index(Request $request)
    {   
        // Validate user page access
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? (int)$request->perPage : ApiHelper::perPageItem();
        $search = $request->search;
        $sortBY = $request->sortBy;
        $ASCTYPE = $request->orderBY;

        $data_query = CRMQuotation::with('crm_quotation_customer')->where('source',$request->source);
        $data_query = ApiHelper::attach_query_permission_filter($data_query, $api_token, $this->page, $this->pageview);

        $dateFormat = ApiHelper::dateFormat();



        if (!empty($search))
           $data_query = $data_query->where("quotation_no", "LIKE", "%{$search}%");

        // if(empty($request->search)){
        /* Add Start Date Filter  */
            if ($request->has('start_date')) {
                if($request->start_date !=NULL){
                    $myDateTime = DateTime::createFromFormat('Y-m-d', $request->start_date);
                    $start_date = $myDateTime->format('Y-m-d');
                    $data_query = $data_query->whereDate('created_at', '>=', $start_date);
            }
            }

            /* Add End Date Filter  */
            if ($request->has('end_date')) {
                if($request->end_date !=NULL){
                    $myDateTime = DateTime::createFromFormat('Y-m-d', $request->end_date);
                    $end_date = $myDateTime->format('Y-m-d');
                    
                    $data_query = $data_query->whereDate('created_at', '<=', $end_date);
                }
            }
        // }

        /* order by sorting */
        if (!empty($sortBY) && !empty($ASCTYPE)) {
            $data_query = $data_query->orderBy($sortBY, $ASCTYPE);
        } else {
            $data_query = $data_query->orderBy('quotation_id', 'DESC');
        }

        $skip = ($current_page == 1) ? 0 : (int)($current_page - 1) * $perPage;
        $user_count = $data_query->count();

        $data_list = $data_query->skip($skip)->take($perPage)->get();

        $currency= ApiHelper::getKeySetVal('default_currency');
        $currency_symbol='';
        if(!empty($currency))
        $currency_symbol = Currency::where('currencies_code', $currency)->first()->symbol_left;


        $res = [
            'quotation_list' => $data_list,
            'current_page' => $current_page,
            'total_records' => $user_count,
            'total_page' => ceil((int)$user_count / (int)$perPage),
            'per_page' => $perPage,
            'date_format' => $dateFormat,
            'start_date'=>$request->start_date,
            'end_date'=>$request->end_date,
            'defaultCurrency' => $currency_symbol,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function create(Request $request)
    {
        $customer = CRMCustomer::where('status', 1)->get();

        foreach ($customer as $crmCustomer) {
            if (!empty($crmCustomer)) {
                $crmCustomer->setRelation('crm_customer_address', $crmCustomer->crm_customer_address()->where(['status' => 1, 'address_type' => 2])->get());
            }

            $address_list = $crmCustomer->crm_customer_address->map(function ($data) {
                $data->country_name = Country::where('countries_id', $data->countries_id)->first()->countries_name;
                return $data;
            });
        }

        $currency = explode(',', ApiHelper::getKeySetVal('other_supported_currency'));
        $defaultCurrency = ApiHelper::getKeySetVal('default_currency');

        $paymentterms = CRMSettingPaymentTerms::all();
        $country = Country::all();

        $crmTaxGroup = CRMSettingTaxGroup::with('tax_info')->where('status', 1)->get();

        $taxTypeIds = [];

        if (!empty($crmTaxGroup)) {
            foreach ($crmTaxGroup as $taxGroup) {
                if (!empty($taxGroup->tax_info)) {
                    foreach ($taxGroup->tax_info as $taxInfo) {
                        $tax_type = CRMSettingTaxType::where('id', $taxInfo->tax_type_id)->first();
                        $taxInfo->tax_name = $tax_type->tax_name;

                        if (!in_array($taxInfo->tax_type_id, $taxTypeIds)) {
                            $taxTypeIds[] = $taxInfo->tax_type_id;
                        }
                    }
                }
            }
        }

        $res = [
            'customer' => $customer,
            'currency' => $currency,
            'country' => $country,
            'paymentterms' => $paymentterms,
            'TaxGroup' => $crmTaxGroup,
            'taxTypeIds' => $taxTypeIds,
            'defaultCurrency' => $defaultCurrency,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }



    public  function SearchSuggestion(Request $request)
    {
        $search = $request->search;
        $ajaxResponse = [];

        $data_query = Product::with('productdescription');

        if (!empty($search)) {
            $data_query = $data_query->where("product_model", "LIKE", "%{$search}%")->orWhere('product_model', 'Like', '%' . $search . '%')->orWhere('product_sku', 'Like', '%' . $search . '%')
                ->orWhereHas('productdescription', function ($data_query) use ($search) {
                    $data_query->where("products_name", "LIKE", "%{$search}%");
                });
        }

        $ajaxResponse['products'] = ApiHelper::getNameAndDesc('product', $data_query->get());

        return ApiHelper::JSON_RESPONSE(true, $ajaxResponse, '');
    }

    // Search-item Detail

    public function SearchItemDetail(Request $request)
    {
        $language = $request->language;
        $product_id = $request->product_id;

        $product =  Product::with('productdescription', 'productAttribute')->where('product_id', $product_id)->first();

        if (!empty($product)) {

            $pr = $product->productdescription()->where('languages_id', $language)->first();
            $product->products_name = ($pr == null) ? '' : $pr->products_name;
            $product->products_description = ($pr == null) ? '' : $pr->products_description;

            // relate with attach attributes
            $attributes = $product->productAttribute()->with('productOptions')->groupBy('options_id')->get();

            if (!empty($attributes)) {
                $attributes->map(function ($option) use ($product) {
                    $option->option_name = $option->productOptions->products_options_name;
                    $option->option_value_list = $product->productAttribute()->with('productOptionsValue')->where('options_id', $option->options_id)->get();
                    return $option;
                });
            }
            $product->productAttribute = $attributes;

            $product->attribute_sale_price = Null;

            $resArray = Product::GetSalePrice($product->product_id);

            $product->sale_price = $resArray['sale_price'];
            $product->bulkPrice = $resArray['bulkPrice'];

            $product_qty = $resArray['qty'] ?? 1;

            $attribute_array = [];

            $itemAttribute = $product->productAttribute()->with('productOptions')->get();

            if (!empty($itemAttribute)) {
                foreach ($itemAttribute as $key => $attribute) {
                    $attribute_array[$key]['options_id'] = $attribute->options_id;
                    $attribute_array[$key]['options_values_id'] = $attribute->options_values_id;
                }

                $request['attribute_array'] = $attribute_array;
                $request['OrderdQty'] = 1;

                $product->attribute_sale_price = $this->attributeToprice($request)->getData()->final_price;
                $product->discount = $this->attributeToprice($request)->getData()->totalDiscountPrice;

                $product->product_qty = $product_qty;
            }

            return ApiHelper::JSON_RESPONSE(true, $product, 'SUCCESS');
        } else {
            return ApiHelper::JSON_RESPONSE(true, [], 'ERROR');
        }
    }


    public function attributeToprice(Request $request)
    {
        $final_price = $attribute_price = $totalPrice = 0;
        $isdiscount = '';

        $helper = new ProductServices();

        $attribute_data = $request;

        if (!empty($attribute_data) && !empty($attribute_data['attribute_array'])) {
            foreach ($attribute_data['attribute_array'] as $key => $value) {
                $attribute_price += Product::attributePrice($request->product_id, $attribute_data['attribute_array'][$key]['options_id'], $attribute_data['attribute_array'][$key]['options_values_id']);
                break;
            }
        }

        $products = Product::find($request->product_id);

        if (!empty($products)) {
            // $products['sale_price'] = $helper->GetSalePrice($request->product_id);

            $resArray = Product::GetSalePrice($request->product_id);

            $products['sale_price'] = $resArray['sale_price'];
            // $product_qty=$resArray['qty'] ?? 1;

            $orderdQty = $request->OrderdQty;

            if ($products->product_price_type == 2) {
                $products_prices = Product::ProductPrices($products->product_id);

                if ($orderdQty < $products_prices->min('product_qty'))
                    $orderdQty = $products_prices->min('product_qty');    // Check  minimum qty otherwise store minimum qty

                $tempArray = 0;
                foreach ($products_prices as $key => $holeprice) {
                    if ($orderdQty >= $holeprice->product_qty) {
                        $tempArray = $holeprice;
                    }
                }

                if (!empty($tempArray)) {
                    if ($tempArray->discount_percent != '0') {
                        $isdiscount = "yes";
                    }
                    $final_price = $tempArray->sale_price + $attribute_price;
                    $totalPrice = $tempArray->max_sale_price + $attribute_price;
                }
            } else {
                if ($products->discount_type != 'no') {
                    $isdiscount = "yes";
                }

                $final_price = $orderdQty * ($products->sale_price + $attribute_price);
                $totalPrice = $orderdQty * ($products->max_sale_price + $attribute_price);
            }
        }

        $result = [
            'isdiscount' => $isdiscount,
            'final_price' => $final_price ?? 0,
            'totalDiscountPrice' => $totalPrice ?? 0,
        ];

        return response()->json($result);
    }

    public function GenerateAndCheck($model, $column_name, $sizeArray)
    {

        $generatedNumber = ApiHelper::generate_random_token('alphabet', $sizeArray[0]) . ApiHelper::generate_random_token('alpha_numeric', $sizeArray[1]);
        $modelpath = str_replace('"', "", 'Modules\CRM\Models' . '\\' . $model);
        $availabel = $modelpath::where($column_name, $generatedNumber)->first();
        if (!empty($availabel)) {
            $this->GenerateAndCheck($model, $column_name, $sizeArray);
        } else {
            return $generatedNumber;
        }
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        // Validate user page access
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        //validation check 
        $rules = [
            'currency' => 'required',
            'customer_id' => 'required',
        ];
        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false, '', $validator->messages());

        $data = $request->only([
            'currency',
            'shipping',
            'shipping_cost',
            'payment_term_id',
            'final_cost',
            'note',
            'discount',
            'total_tax',
            'billing_address_id',
            'source'
        ]);

        $data['quotation_no'] = $this->GenerateAndCheck('CRMQuotation', 'quotation_no', [3, 7]);

        $data['tax_group_id'] = (int)$request->default_tax_group;
        $data['subtotal'] = (float)$request->subtotal;

        $Insert['created_by']= User::where('api_token', $request->api_token)->first()->id;

        try {
            \DB::beginTransaction();

            if ($request->has('customer_id'))
                $data['customer_id'] = $request->customer_id;

            if ($request->tax_type == "no")
                $data['tax_type'] = 1;
            else
                $data['tax_type'] = 0;

            // $data['total_tax'] = $request->final_cost - $request->subtotal;

            $quotation = CRMQuotation::create($data);

            $customer=CRMCustomer::find($request->customer_id);

            $lstquotationid = $quotation->quotation_id;

              // Add lead
              $lead = CRMLead::firstOrCreate(
                ['contact_email' =>$customer->email],
                [   
                    'customer_id'=>$customer->customer_id,
                    'contact_name' => $customer->first_name,
                    'phone' =>$customer->contact,
                ]
            );

            $lead_followup = CRMLeadFollowUp::create([
                'lead_id'=>$lead->lead_id,
                'source'=>3,
                'source_id'=>$lstquotationid,
            ]);
            

            

            $item_name = $request->item_name;
            $quantity = $request->quantity;
            $unit_price = $request->unit_price;
            $item_discount = $request->item_discount;
            $item_id = $request->item_id;
            $tax_group_id = $request->tax_group_id;
            $item_cost = $request->item_cost;
            $sac_code = $request->sac_code;
            $attributeArray = [];

            if (!empty($request->item_attributes)) {
                foreach ($request->item_attributes as $attributes) {
                    $attributeArray[] = $attributes;
                }
            }
            foreach ($item_name as $key => $value) {

                $cal_qty = $quantity[$key] ?? 1;
                $cal_unit_price = $unit_price[$key] ?? 0;
                $cal_discount = $item_discount[$key] ?? 0;
                $tax_percetages = CRMSettingTaxPercentage::where('tax_group_id', $tax_group_id[$key])->sum('tax_percent');

                $tax_amount = ((($cal_qty * $cal_unit_price) - $cal_discount) * $tax_percetages) / 100;

                $CRMQuotationItem = CRMQuotationItem::create([
                    'quotation_id' => $lstquotationid,
                    'item_name' =>  $item_name[$key] ?? 0,
                    'item_id' => $item_id[$key] ?? 0,
                    'sac_code' => $sac_code[$key] ?? '',
                    'quantity' => $quantity[$key] ?? 1,
                    'unit_price' => $unit_price[$key] ?? 0,
                    'discount' => $item_discount[$key] ?? 0,
                    'item_cost' => $item_cost[$key]  ?? 0,
                    'tax_group_id' => $tax_group_id[$key] ?? 0,
                    'tax_amount' => $tax_amount,
                    'attributes' => sizeof($attributeArray) > 0 ? json_encode($attributeArray[$key]) : NULL,
                    'updated_at' => date("Y-m-d"),
                ]);
            }

            \DB::commit();      // COMMIT DB TRANSACTION

            // $msag = 'Quotation : ' . $quotation->quotation_no . ' Created successfully !';
            // $title = 'Quotation';
            // ApiHelper::realtimeNoti([
            //     'user_id' => ApiHelper::get_adminid_from_token($api_token),
            //     'type' => 1,
            //     'msg' => $msag,
            //     'title' => $title
            // ]);  // generate notifiction

            return ApiHelper::JSON_RESPONSE(true, $quotation, 'SUCCESS_QUOTATION_ADD');
        } catch (\Throwable $th) {
            \DB::rollback();    // ROLLBACK IF ANY ERROR OCCUR WHILE STORING DB

            return ApiHelper::JSON_RESPONSE(false, '', $th->getMessage());
        }
    }


    public function leatToCustomer($lead_id)
    {
        $arrayData = [];

        if (!empty($lead_id)) {
            $leadrecords = CRMLead::find($lead_id);
            $customerquotation = CRMCustomer::create([
                'company_name' => $leadrecords->contact_name,
                //  'email' => $leadrecords->contact_email,
                'lead_id' => $lead_id,
            ]);

            $customerquotationaddress = CRMCustomerAddress::create([
                'street_address' => $leadrecords->address,
                'city' => $leadrecords->city,
                'state' => $leadrecords->state,
                'zipcode' => $leadrecords->zipcode,
                'countries_id' => $leadrecords->countries_id,
                'phone' => $leadrecords->phone,
                'customer_id' => $customerquotation->customer_id,
            ]);

            $Leadcontact = CRMLeadContact::select('contact_name', 'contact_email')->where('lead_id', $lead_id)->get();

            $billing_contact_id = 0;

            if (!empty($Leadcontact)) {
                foreach ($Leadcontact as $key => $contact) {
                    $contact = (array)$contact;
                    $contact['customer_id'] = $customerquotation->customer_id;
                    $data = CRMCustomerContact::create($contact);
                    $billing_contact_id = $data->contact_id;
                }
            }

            $arrayData['customer_id'] = $customerquotation->customer_id;
            $arrayData['billing_address_id'] = $customerquotationaddress->address_id;
            $arrayData['billing_contact_id'] = $billing_contact_id;
        }
        return $arrayData;
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
        $quotation = CRMQuotation::with('crm_quotation_item')->find($request->quotation_id);
        $quotation->currency_symbol = Currency::where('currencies_code', $quotation->currency)->first()->symbol_left;
        if (!empty($quotation)) {
            $data_list = $quotation->crm_quotation_item->map(function ($data) use ($request) {
                $data->tax_group_name = ApiHelper::getGroupName($data->tax_group_id);
                if (!empty($data->item_id)) {
                    $request->request->add(['product_id' => $data->item_id, 'language' => 1]);
                    $product_data = $this->SearchItemDetail($request)->getData()->data; // Call the function for Product detail with price

                    $data->product_data = $product_data;
                }
                return $data;
            });
        }

        $customer_addrs = CRMCustomerAddress::where('address_id', $quotation->billing_address_id)->first();
        if (!empty($customer_addrs))
            $customer_addrs['country_name'] = Country::where('countries_id', $customer_addrs->countries_id)->first()->countries_name;



        $customer = CRMCustomer::where('status', 1)->get();

        foreach ($customer as $crmCustomer) {
            if (!empty($crmCustomer)) {
                $crmCustomer->setRelation('crm_customer_address', $crmCustomer->crm_customer_address()->where(['status' => 1, 'address_type' => 2])->get());
            }

            $address_list = $crmCustomer->crm_customer_address->map(function ($data) {
                $data->country_name = Country::where('countries_id', $data->countries_id)->first()->countries_name;
                return $data;
            });
        }

        $currency = explode(',', ApiHelper::getKeySetVal('other_supported_currency'));
        $defaultCurrency = ApiHelper::getKeySetVal('default_currency');

        $paymentterms = CRMSettingPaymentTerms::all();
        $country = Country::all();

        $crmTaxGroup = CRMSettingTaxGroup::with('tax_info')->where('status', 1)->get();

        $taxTypeIds = [];

        if (!empty($crmTaxGroup)) {
            foreach ($crmTaxGroup as $taxGroup) {
                if (!empty($taxGroup->tax_info)) {
                    foreach ($taxGroup->tax_info as $taxInfo) {
                        $tax_type = CRMSettingTaxType::where('id', $taxInfo->tax_type_id)->first();
                        $taxInfo->tax_name = $tax_type->tax_name;

                        if (!in_array($taxInfo->tax_type_id, $taxTypeIds)) {
                            $taxTypeIds[] = $taxInfo->tax_type_id;
                        }
                    }
                }
            }
        }

        // Invoice Sender Data Work Here  

        $invoice_data = [];

        $invoice_data['invoice_logo'] = ApiHelper::getKeySetVal('invoice_logo');
        $invoice_data['invoice_note'] = ApiHelper::getKeySetVal('invoice_note');
        $invoice_data['invoice_prefix'] = ApiHelper::getKeySetVal('invoice_prefix');

        $invoice_data['invoice_biller_address'] = !empty(ApiHelper::getKeySetVal('invoice_biller_address')) ? ApiHelper::getKeySetVal('invoice_biller_address') : ApiHelper::getKeyVal('contact_address')
            . ' ,' . ApiHelper::getKeyVal('contact_city') . ' ,' . ApiHelper::getKeyVal('contact_state') . ' ,' . ApiHelper::getKeyVal('contact_country') . ' ,' . ApiHelper::getKeyVal('contact_zipcode');
        $invoice_data['business_email'] = ApiHelper::getKeySetVal('business_email');
        $invoice_data['contact_phone'] = ApiHelper::getKeyVal('contact_phone');
        $invoice_data['company_name'] = !empty(ApiHelper::getKeySetVal('business_name')) ? ApiHelper::getKeySetVal('business_name') : ApiHelper::getKeyVal('company_name');

        $customer_addrs = CRMCustomerAddress::where('address_id', $quotation->billing_address_id)->first();
        if (!empty($customer_addrs))
            $customer_addrs['country_name'] = Country::where('countries_id', $customer_addrs->countries_id)->first()->countries_name;

        $invoice_data['customer_address'] = $customer_addrs;

        $res = [
            'customer' => $customer,
            'currency' => $currency,
            'country' => $country,
            'paymentterms' => $paymentterms,
            'TaxGroup' => $crmTaxGroup,
            'taxTypeIds' => $taxTypeIds,
            'quotation' => $quotation,
            'invoice_data' => $invoice_data,
            'defaultCurrency' => $defaultCurrency,
            'website_url'=>ApiHelper::getKeyVal('website_url'),
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function quotationdetailspdf(Request $request)
    {
        $api_token = $request->api_token;

        $response = CRMQuotation::with('crm_quotation_item', 'crm_quotation_customer', 'crm_quotation_address',)->where('quotation_no', $request->quotation_no)->first();
        $response->currency_symbol = Currency::where('currencies_code', $response->currency)->first()->symbol_left;
        if(!empty($response->crm_quotation_address))
        $response->crm_quotation_address->country_name=Country::where('countries_id',$response->crm_quotation_address->countries_id)->first()->countries_name;

        if (!empty($response)) {
            $data_list = $response->crm_quotation_item->map(function ($data) use ($request) {
                $data->tax_group_name = ApiHelper::getGroupName($data->tax_group_id);
                if (!empty($data->item_id)) {
                    $request->request->add(['product_id' => $data->item_id, 'language' => 1]);
                    $product_data = $this->SearchItemDetail($request)->getData()->data; // Call the function for Product detail with price

                    $data->product_data = $product_data;
                }
                return $data;
            });
        }


        // Invoice Sender Data Work Here  

        $invoice_data = [];

        $invoice_data['invoice_logo'] = ApiHelper::getFullImageUrl(ApiHelper::getKeySetVal('invoice_logo'));
        $invoice_data['invoice_note'] = ApiHelper::getKeySetVal('invoice_note');
        $invoice_data['invoice_prefix'] = ApiHelper::getKeySetVal('invoice_prefix');
        $invoice_data['term_condition'] = ApiHelper::getKeySetVal('invoice_term_and_condition');
        $invoice_data['invoice_note'] = ApiHelper::getKeySetVal('invoice_note');
        $invoice_data['bank_account'] = ApiHelper::getKeySetVal('invoice_bank_account');

        $invoice_data['invoice_biller_address'] = !empty(ApiHelper::getKeySetVal('invoice_biller_address')) ? ApiHelper::getKeySetVal('invoice_biller_address') : ApiHelper::getKeyVal('contact_address')
            . ' ,' . ApiHelper::getKeyVal('contact_city') . ' ,' . ApiHelper::getKeyVal('contact_state') . ' ,' . ApiHelper::getKeyVal('contact_country') . ' ,' . ApiHelper::getKeyVal('contact_zipcode');
        $invoice_data['business_email'] = ApiHelper::getKeySetVal('business_email');
        $invoice_data['contact_phone'] = ApiHelper::getKeyVal('contact_phone');
        $invoice_data['company_name'] = !empty(ApiHelper::getKeySetVal('business_name')) ? ApiHelper::getKeySetVal('business_name') : ApiHelper::getKeyVal('company_name');


        $res = [
            'quote_detail' => $response,
            'invoice_data'=>$invoice_data,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }


    public function customeralldata(Request $request)
    {
        $customerid = $request->customer_id;

        $contactdata = CRMCustomerContact::where('customer_id', $customerid)->get();
        $addressdata = CRMCustomerAddress::where('customer_id', $customerid)->get();

        $res = [
            'contactdata' => $contactdata,
            'addressdata' => $addressdata,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');



        //validation check 
        $rules = [
            'currency' => 'required',
            'customer_id' => 'required',
        ];
        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false, '', $validator->messages());

        try {
            $data = $request->only([
                'currency',
                'shipping',
                'shipping_cost',
                'payment_term_id',
                'final_cost',
                'note',
                'discount',
                'total_tax',
                'billing_address_id',
            ]);

            // $data['quotation_no'] = $this->GenerateAndCheck('CRMQuotation','quotation_no',[3,7]);

            $data['tax_group_id'] = (int)$request->default_tax_group;
            $data['subtotal'] = (float)$request->subtotal;

            if ($request->has('customer_id'))
                $data['customer_id'] = $request->customer_id;

            if ($request->tax_type == "no")
                $data['tax_type'] = 1;
            else
                $data['tax_type'] = 0;

            // $data['total_tax'] = $request->final_cost - $request->subtotal;

            $quotation = CRMQuotation::where('quotation_id', $request->quotation_id)->update($data);

            $lstquotationid = $request->quotation_id;

            $item_name = $request->item_name;
            $quantity = $request->quantity;
            $unit_price = $request->unit_price;
            $item_discount = $request->item_discount;
            $item_id = $request->item_id;
            $tax_group_id = $request->tax_group_id;
            $item_cost = $request->item_cost;
            $sac_code = $request->sac_code;
            $attributeArray = [];

            if (!empty($request->item_attributes)) {
                foreach ($request->item_attributes as $attributes) {
                    $attributeArray[] = $attributes;
                }
            }

            CRMQuotationItem::where('quotation_id', $request->quotation_id)->delete();

            foreach ($item_name as $key => $value) {

                $cal_qty = $quantity[$key] ?? 1;
                $cal_unit_price = $unit_price[$key] ?? 0;
                $cal_discount = $item_discount[$key] ?? 0;
                $tax_percetages = CRMSettingTaxPercentage::where('tax_group_id', $tax_group_id[$key])->sum('tax_percent');

                $tax_amount = ((($cal_qty * $cal_unit_price) - $cal_discount) * $tax_percetages) / 100;

                $CRMQuotationItem = CRMQuotationItem::create([
                    'quotation_id' => $lstquotationid,
                    'item_name' =>  $item_name[$key] ?? 0,
                    'item_id' => $item_id[$key] ?? 0,
                    'sac_code' => $sac_code[$key] ?? '',
                    'quantity' => $quantity[$key] ?? 0,
                    'unit_price' => $unit_price[$key] ?? 0,
                    'discount' => $item_discount[$key] ?? 0,
                    'item_cost' => $item_cost[$key]  ?? 0,
                    'tax_group_id' => $tax_group_id[$key] ?? 0,
                    'tax_amount' => $tax_amount,
                    'attributes' => sizeof($attributeArray) > 00 ? json_encode($attributeArray[$key]) : NULL,
                    'updated_at' => date("Y-m-d"),
                ]);
            }
            return ApiHelper::JSON_RESPONSE(true, $quotation, 'SUCCESS_QUOTATION_UPDATE');
        } catch (Exception $e) {
            return ApiHelper::JSON_RESPONSE(false, $e->getMessage(), 'ERROR_QUOTATION_UPDATE');
        }
    }

    public function ContactsInformation(Request $request)
    {

        if ($request->contact_type == "address") {
            $adddata = $request->only(
                'customer_id',
                'address_type',
                'street_address',
                'city',
                'state',
                'zipcode',
                'countries_id',
                'phone',
            );
            $AddressData = CRMCustomerAddress::create($adddata);
            return ApiHelper::JSON_RESPONSE(true, $AddressData, 'CUSTOMER_ADDRESS_CREATED');
        }
        if ($request->contact_type == "contact") {
            $contact_data = $request->only('customer_id', 'contact_name', 'contact_email');
            $ContactData = CRMCustomerContact::create($contact_data);
            return ApiHelper::JSON_RESPONSE(true, $ContactData, 'SUCCESS_CUSTOMER_CONTACT_ADD');
        }
    }



    public function changeStatus(Request $request)
    {
        $quoteId = $request->quoteId;
        $statusId = $request->statusId;

        if (empty($statusId) || empty($quoteId))
            return ApiHelper::JSON_RESPONSE(false, '', 'SOME_FIELD_MISSING');

        $quote = CRMQuotation::find($quoteId);
        $quote->status = $statusId;
        $quote->save();

        if ($quote)
            return ApiHelper::JSON_RESPONSE(true, $quote, 'SUCCESS_STATUS_UPDATE');
        else
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_STATUS_UPDATE');
    }


    // This function used for send mail to user 

    public function mailSenderHelper($Quote_data)
    {  
        $customer_data=CRMCustomer::find($Quote_data->customer_id);

        $dt = Carbon::now();
        $today_date = $dt->toDateString();

        $mail_data = [
            'sender_name' =>'Sender Name',
            'sender_email' => 'senderemail@gmail.com',
            'subject' => "Quotation Reminder",
            'content' => "Please Pay your payment",
            // 'unsubscription_url' => url()->full(),
            'customer_data' => $customer_data,
            'web_base_url' => ApiHelper::getKeyVal('website_url'),
        ];

        try {
            QuoteReminderHistory::create([
                'quote_id'=>$Quote_data->quotation_id,
                'sent_at'=>$today_date,
            ]);
            QuoteReminderJob::dispatch($mail_data)->delay(now()->addSeconds(value: 5));
        } catch (Exception $e) {
            echo ($e->getMessage());
        }

    }
    

    // Send Reminder Emails for quotation

    public function sendReminder()
    {
        $invoice_send_reminder=ApiHelper::getKeySetVal('invoice_send_reminder');
        $invoice_reminder_interval=ApiHelper::getKeySetVal('invoice_reminder_interval');
        $invoice_reminder_times=ApiHelper::getKeySetVal('invoice_reminder_times');

        if($invoice_send_reminder==1)
        {
            $dt = Carbon::now();
            $today_date = $dt->toDateString();

            $quoteObject=CRMQuotation::where('status',2)->get();
            
            if (!empty($quoteObject)) {
                foreach ($quoteObject as $Quote_data) {

                    $quoteHist=QuoteReminderHistory::where('quote_id',$Quote_data->quotation_id)->orderBy('id', 'DESC')->get();
                   
                    $total_interval=0;
                 
                    if(sizeof($quoteHist)>0)
                    {
                        $end_date = Carbon::parse($quoteHist[0]->sent_at);
                        $total_interval = $end_date->diffInDays($today_date);
                    }
                    
                    if(sizeof($quoteHist)==0)
                    {
                        $this->mailSenderHelper($Quote_data);
                    }
                    elseif(sizeof($quoteHist)>0 && count($quoteHist)<$invoice_reminder_times && $total_interval>$invoice_reminder_interval)
                    {
                        $this->mailSenderHelper($Quote_data);
                    }
                    else
                    {
                        return ApiHelper::JSON_RESPONSE(true, [], 'MAIL_ALREADY_SEND');
                    }
                }
            }

        }

    }
}
