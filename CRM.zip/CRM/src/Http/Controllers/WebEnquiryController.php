<?php

namespace Modules\CRM\Http\Controllers;

use ApiHelper;
use App\Http\Controllers\Controller;
use App\Jobs\EnquiryUpdateMail;
use DateTime;
use Illuminate\Http\Request;
use Modules\CRM\Models\Enquiry;
use Modules\CRM\Models\Super\SuperEnquiry;
use Modules\Ecommerce\Models\ProductOptions;
use Modules\Ecommerce\Models\ProductsOptionsValues;

class WebEnquiryController extends Controller
{
    public $page = 'sales-enquiry';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';

    public function index(Request $request)
    {

        //Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? $request->perPage :  ApiHelper::perPageItem();
        $search = $request->search;
        $sortBy = $request->sortBy;
        $orderBy = $request->orderBy;

        /*Fetching subscriber data*/
        if ($userType == 'subscriber') {

            $enquiry_query = Enquiry::with('enquiry_product', 'enquiry_product.products.productdescription', 'country_details');
            if (!empty($search)) {
                $enquiry_query = $enquiry_query->where("customers_name", "LIKE", "%{$search}%")
                    ->orWhere("email_address", "LIKE", "%{$search}%")->orWhere("company_name", "LIKE", "%{$search}%")
                    ->orWhere("enquiry_no", "LIKE", "%{$search}%");
            }
        } else {

            $enquiry_query = SuperEnquiry::with('country_details');
            if (!empty($search)) {
                $enquiry_query = $enquiry_query->where("customer_name", "LIKE", "%{$search}%")
                    ->orWhere("customer_email", "LIKE", "%{$search}%")->orWhere("company_name", "LIKE", "%{$search}%")
                    ->orWhere("enquiry_no", "LIKE", "%{$search}%");
            }
        }

        // $enquiry_query = Enquiry::with('enquiry_product', 'enquiry_product.products.productdescription', 'country_details');
        //   $enquiry_query = ApiHelper::attach_query_permission_filter($enquiry_query, $api_token, $this->page, $this->pageview);

        /*Checking if search data is not empty*/
        // if (!empty($search)) {
        //     $enquiry_query = $enquiry_query->where("customers_name", "LIKE", "%{$search}%")
        //         ->orWhere("email_address", "LIKE", "%{$search}%")->orWhere("company_name", "LIKE", "%{$search}%")
        //         ->orWhere("enquiry_no", "LIKE", "%{$search}%");
        // }

        if (empty($request->search)) {
            /* Add Start Date Filter  */
            if ($request->has('start_date')) {
                if ($request->start_date != null) {
                    $myDateTime = DateTime::createFromFormat('Y-m-d', $request->start_date);
                    $start_date = $myDateTime->format('Y-m-d');
                    $enquiry_query = $enquiry_query->whereDate('created_at', '>=', $start_date);
                }
            }

            /* Add End Date Filter  */
            if ($request->has('end_date')) {
                if ($request->end_date != null) {
                    $myDateTime = DateTime::createFromFormat('Y-m-d', $request->end_date);
                    $end_date = $myDateTime->format('Y-m-d');
                    $enquiry_query = $enquiry_query->whereDate('created_at', '<=', $end_date);
                }
            }
        }

        /* order by sorting */
        if (!empty($sortBy) && !empty($orderBy)) {
            $enquiry_query = $enquiry_query->orderBy($sortBy, $orderBy);
        } else {
            $enquiry_query = $enquiry_query->orderBy('enquiry_id', 'DESC');
        }

        $skip = ($current_page == 1) ? 0 : (int) ($current_page - 1) * $perPage;

        $enquiry_count = $enquiry_query->count();

        $enquiry_list = $enquiry_query->skip($skip)->take($perPage)->get();

        $enquiry_list = $enquiry_list->map(function ($data) {

            $data->Country = !empty($data->country_details) ? $data->country_details->countries_name : "-";

            return $data;
        });

        /*Binding data into a variable*/
        $res = [
            'enquiry_list' => $enquiry_list,
            'current_page' => $current_page,
            'total_records' => $enquiry_count,
            'total_page' => ceil((int) $enquiry_count / (int) $perPage),
            'per_page' => $perPage,
            'start_date' => $request->start_date,
            'end_date' => $request->end_date,
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function changeStatus(Request $request)
    {

        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        if ($userType == 'subscriber') {

            $enquiry_id = $request->enquiry_id;
            $sub_data = Enquiry::find($enquiry_id);
            $sub_data->status = $request->status;
            $sub_data->save();
        } else {
            $enquiry_id = $request->enquiry_id;
            $sub_data = SuperEnquiry::find($enquiry_id);
            $sub_data->status = $request->status;
            $sub_data->save();
        }

        return ApiHelper::JSON_RESPONSE(true, $sub_data, 'SUCCESS_STATUS_UPDATE');
    }

    public function store(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $enquiry_id = $request->enquiry_id;
        $details = '';
        // $data = Enquiry::UpdateOrCreate(
        //     ['lead_id' => $lead_id],
        //   [
        //       'followup_status' => $request->followup_status,
        //       'next_followup' => $request->next_followup,

        //   ]);

        //   $business_id = $subscription_data->business_id;

        if ($userType == 'subscriber') {

            $enquiry_details = Enquiry::find($enquiry_id);

            $message = $request->message;

            if (!empty($message)) {
                $details = [
                    'email' => $enquiry_details->email_address,
                    'message' => $message,
                ];
            }

            EnquiryUpdateMail::dispatch($details);
        } else {

            $enquiry_details = SuperEnquiry::find($enquiry_id);

            $message = $request->message;

            if (!empty($message)) {
                $details = [
                    'email' => $enquiry_details->email_address,
                    'message' => $message,
                ];
            }

            EnquiryUpdateMail::dispatch($details);
        }

        if ($details) {
            return ApiHelper::JSON_RESPONSE(true, $details, 'SUCCESS_ENQUIRY_ADD');
        } else {
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_ENQUIRY_ADD');
        }
    }

    public function enquiry_details(Request $request)
    {

        //Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);

        $product_details = '';

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        if ($userType == 'subscriber') {
            $website_url = ApiHelper::getKeyVal('website_url');
            $enquiry_list = Enquiry::with('enquiry_product', 'enquiry_product.products.productdescription', 'country_details')->where('enquiry_id', $request->enquiry_id)->first();

            $enquiry_list->country_name = $enquiry_list->country_details->countries_name ?? '';

            if (!empty($enquiry_list->enquiry_product)) {
                $enquiry_list->enquiry_product->products->product_name = $enquiry_list->enquiry_product->products->productdescription[0]->products_name;
                $product_attribute = $enquiry_list->enquiry_product->products_attributes_id;
            }

            $attribute_array = [];
            if (!empty($product_attribute)) {
                foreach (json_decode($product_attribute) as $key => $value) {
                    $productOption = ProductsOptionsValues::where('products_options_values_id', $value)->first();
                    if (!empty($productOption)) {
                        $attribute_name = ProductOptions::where('products_options_id', $productOption->products_options_id)->first()->products_options_name;
                        $attribute_array[$attribute_name][] = $productOption->products_options_values_name;
                    }
                }
            }
        } else {

            $enquiry_list = SuperEnquiry::with('country_details')->where('enquiry_id', $request->enquiry_id)->first();

            $enquiry_list->country_name = $enquiry_list->country_details->countries_name ?? '';

            // if (!empty($enquiry_list->enquiry_product)) {
            //     $enquiry_list->enquiry_product->products->product_name = $enquiry_list->enquiry_product->products->productdescription[0]->products_name;
            //     $product_attribute = $enquiry_list->enquiry_product->products_attributes_id;
            // }

            // $attribute_array = [];
            // if (!empty($product_attribute)) {
            //     foreach (json_decode($product_attribute) as $key => $value) {
            //         $productOption = ProductsOptionsValues::where('products_options_values_id', $value)->first();
            //         if (!empty($productOption)) {
            //             $attribute_name = ProductOptions::where('products_options_id', $productOption->products_options_id)->first()->products_options_name;
            //             $attribute_array[$attribute_name][] = $productOption->products_options_values_name;
            //         }
            //     }
            // }
            $attribute_array = '';
            $website_url = '';
        }

        /*Binding data into a variable*/
        $res = [
            'enquiry_list' => $enquiry_list,
            'attributes_data' => $attribute_array,
            'website_url' => $website_url
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }
}
