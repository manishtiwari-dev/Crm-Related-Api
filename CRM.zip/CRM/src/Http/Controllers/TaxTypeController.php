<?php

namespace Modules\CRM\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use ApiHelper;
use Modules\CRM\Models\CRMSettingTaxGroup;
use Modules\CRM\Models\CRMSettingTax;
use Modules\CRM\Models\CRMSettingTaxType;



class TaxTypeController extends Controller
{

    public $page = 'tax_setting';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */



    public function create()
    {

        $taxType = CRMSettingTaxType::where('status', 1)->get();

        $res = [
            'taxType' => $taxType,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }


    public function edit($id)
    {
        //
    }

    public function store(Request $request)
    {

        $data = new CRMSettingTaxType;
        $data->tax_name = $request->tax_name;
        $data->save();

        $data = CRMSettingTaxType::all();

        if ($data) {
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_TAX_TYPE_ADD');
        } else {
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_TAX_TYPE_ADD');
        }
    }

    public function update(Request $request)
    {
        $data = CRMSettingTaxType::findOrFail($request->id);
        $data->tax_name = $request->tax_name;
        $data->save();

        $data = CRMSettingTaxType::all();

        if ($data) {
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_TAX_TYPE_UPDATE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_TAX_TYPE_UPDATE');
        }
    }

    public function destroy(Request $request)
    {
        // CRMSettingTaxGroup::destroy($request->tax_group_id);

        $infoData =  CRMSettingTaxType::findOrFail($request->id);
        if (!empty($infoData)) {
            $infoData->tax_name =  $infoData->tax_name;
            $infoData->status = 0;
            $infoData->save();
        }

        $data = CRMSettingTaxType::all();

        if ($data) {
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_DELETE_TAX_TYPE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_JOB_TAX_DELETE');
        }
    }
}
