<?php

namespace Modules\CRM\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\CRM\Models\AccCategories;
use Illuminate\Support\Facades\Validator;
use ApiHelper;
use Modules\CRM\Models\AccAccounts;
use App\Models\Currency;

class SettingController extends Controller
{

    public $page = 'setting';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    public function index(Request $request)
    {


        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');



        $currency = Currency::all();
        $crmexpansecategory = AccCategories::all();
        $appAccounts = AccAccounts::all();
        $res = [
            'crmexpansecategory' => $crmexpansecategory,
            'currency' => $currency,
            'appAccounts' => $appAccounts
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function create(Request $request)
    {
        return ApiHelper::JSON_RESPONSE(true, [], '');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        $category = AccCategories::where('name', $request->expense_name)->first();

        if (!empty($category)) {
            return ApiHelper::JSON_RESPONSE(false, '', 'TRANSACTION_CATEGORY_ALREADY_EXIST');
        } else {
            $crmexpensecategory = AccCategories::create([
                'name' => $request->expense_name,
                'description' => $request->expense_category
            ]);
        }



        return ApiHelper::JSON_RESPONSE(true, $crmexpensecategory, 'SUCCESS_TRANSACTION_ADD');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {


        $api_token = $request->api_token;
        $expense = AccCategories::find($request->expense_id);


        $response = [
            'expense' => $expense,

        ];




        return ApiHelper::JSON_RESPONSE(true, $response, '');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');



        $expense_category = AccCategories::find($request->id);
        $expense_category->name = $request->expense_name;
        $expense_category->description = $request->editexpense_description;
        $expense_category->update();


        if ($expense_category) {
            return ApiHelper::JSON_RESPONSE(true, $expense_category, 'SUCCESS_SETTING_CATEGORY_UPDATE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_SETTING_CATEGORY_UPDATE');
        }
    }

    public function destroy(Request $request)
    {

        AccCategories::where('id', $request->id)->delete();

        return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_DELETE_TRANSACTION_CATEGORY');
    }

    public function destroyAccount(Request $request)
    {

        AccAccounts::where('id', $request->id)->delete();

        return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_DELETE_ACCOUNT');
    }



    public function accountStore(Request $request)
    {
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        $account = AccAccounts::where('account_number', $request->account_number)->first();

        if (!empty($account)) {
            return ApiHelper::JSON_RESPONSE(false, '', 'ACCOUNT_NO_ALREADY_EXIST');
        } else {
            $app_accounts = AccAccounts::create([
                'account_title' => $request->account_title,
                'opening_date' => $request->opening_date,
                'account_number' => $request->account_number,
                'account_currency' => $request->account_currency,
                'opening_balance' => $request->opening_balence,
                'note' => $request->note,
            ]);
        }


        return ApiHelper::JSON_RESPONSE(true, $app_accounts, 'SUCCESS_ACCOUNT_ADD');
    }

    public function accountEdit(Request $request)
    {
        $api_token = $request->api_token;
        $account = AccAccounts::find($request->account_id);


        $res = [
            'account' => $account,

        ];




        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }


    public function updateAccount(Request $request)
    {
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');



        $app_accounts = AccAccounts::find($request->id);
        $app_accounts->account_title = $request->edit_account_title;
        $app_accounts->opening_date = $request->edit_opening_date;
        $app_accounts->account_number = $request->edit_account_number;
        $app_accounts->account_currency = $request->edit_account_currency;
        $app_accounts->opening_balance = $request->edit_opening_balence;
        $app_accounts->closing_balance = $request->closing_balance;
        $app_accounts->note = $request->edit_note;
        $app_accounts->update();


        if ($app_accounts) {
            return ApiHelper::JSON_RESPONSE(true, $app_accounts, 'SUCCESS_CATEGORY_UPDATE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_ACCOUNTS_UPDATE');
        }
    }

    public function changeStatus(Request $request)
    {
        $api_token = $request->api_token;

        $category =  AccCategories::where('id', $request->cate_id)->first();
        $category->status = $request->status;
        $category->update();
        return ApiHelper::JSON_RESPONSE(true, $category, 'SUCCESS_STATUS_UPDATE');
    }

    public function changeAccStatus(Request $request)
    {
        $api_token = $request->api_token;

        $account =  AccAccounts::where('id', $request->account_id)->first();
        $account->status = $request->status;
        $account->update();
        return ApiHelper::JSON_RESPONSE(true, $account, 'SUCCESS_STATUS_UPDATE');
    }
}
