<?php

namespace Modules\CRM\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Currency;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Modules\CRM\Models\CRMExpenses;
use Modules\CRM\Models\CRMExpensesCategories;
use Modules\CRM\Models\CRMSettingTaxType;
use Modules\CRM\Models\CRMSettingTaxGroup;
use Modules\CRM\Models\AppTransactions;
use Modules\CRM\Models\CRMCustomer;
use ApiHelper;
use Carbon\Carbon;
use Modules\CRM\Models\AppAccounts;
use Illuminate\Support\Facades\Storage;
use App\Models\PaymentMethods;
use Modules\CRM\Models\AppRepeatTransactions;


class IncomeController extends Controller
{

    public $page = 'income';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    public function index(Request $request)
    {
        $app_transactions =  AppTransactions::with('Accounts')->get();


        $res = [
            'app_transactions' => $app_transactions,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function create(Request $request)
    {

        $crm_expense_category = CRMExpensesCategories::all();
        $currency = explode(',', ApiHelper::getKeySetVal('other_supported_currency'));
        $defaultCurrency = ApiHelper::getKeySetVal('default_currency');
        $SelectedTaxGroup = ApiHelper::getKeySetVal('tax_group');
        $crmTaxGroup = CRMSettingTaxGroup::with('tax_info')->where('status', 1)->get();
        $paymentMethodList = PaymentMethods::all();

        $taxTypeIds = [];

        if (!empty($crmTaxGroup)) {
            foreach ($crmTaxGroup as $taxGroup) {
                if (!empty($taxGroup->tax_info)) {
                    foreach ($taxGroup->tax_info as $taxInfo) {
                        $tax_type = CRMSettingTaxType::where('id', $taxInfo->tax_type_id)->first();
                        $taxInfo->tax_name = $tax_type->tax_name;

                        if (!in_array($taxInfo->tax_type_id, $taxTypeIds)) {
                            $taxTypeIds[] = $taxInfo->tax_type_id;
                        }
                    }
                }
            }
        }



        $customers = CRMCustomer::all();
        $accounts = AppAccounts::all();

        $res = [
            "crm_expense_category" => $crm_expense_category,
            "currency" => $currency,
            "TaxGroup" => $crmTaxGroup,
            "customers" => $customers,
            "accounts" => $accounts,
            'defaultCurrency' => $defaultCurrency,
            'SelectedTaxGroup' => $SelectedTaxGroup,
            'paymentMethodList' => $paymentMethodList

        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        // $invoice = new AppInvoices();
        // $invoice->invoice_date = $request->date;
        // $invoice->note = $request->note;
        // $invoice->status = 1;


        $appTransaction = new AppTransactions();

        $appTransaction->trans_date = Carbon::createFromFormat('d-m-Y', $request->date)->format(' Y-m-d');
        $appTransaction->account_id = $request->account;
        $appTransaction->type = "income";
        $appTransaction->dr_cr = "cr";
        $appTransaction->amount = $request->amount;
        $appTransaction->payment_method_id = $request->payment_method_id;
        $appTransaction->payer_payee_id = $request->payer_payee_id;
        $appTransaction->reference = $request->reference;
        $appTransaction->note = $request->note;



        if ($request->hasFile('attachment')) {
            $image = $request->attachment;

            $times = time();
            $extension = $image->getClientOriginalExtension();
            $folder = ApiHelper::db_folder($api_token);

            $dir = $folder . "/sales/transactions/";

            $path = $image->storeAs($dir, $times . '.' . $extension);

            $appTransaction->attachment = $times . '.' . $extension;
        };

        $appTransaction->save();

        if ($request->has('recurring')) {
            $appRepeatTransaction = new AppRepeatTransactions();
            $appRepeatTransaction->trans_date = Carbon::createFromFormat('d-m-Y', $request->date)->format(' Y-m-d');
            $appRepeatTransaction->account_id = $request->account;
            $appRepeatTransaction->type = "income";
            $appRepeatTransaction->dr_cr = "dr";
            $appRepeatTransaction->amount = $request->amount;
            $appRepeatTransaction->payment_method_id = $request->payment_method_id;
            $appRepeatTransaction->payer_payee_id = $request->payer_payee_id;
            $appRepeatTransaction->reference = $request->reference;
            $appRepeatTransaction->note = $request->note;
            $appRepeatTransaction->save();
        }




        return ApiHelper::JSON_RESPONSE(true, $appTransaction, 'SUCCESS_INCOME_ADD');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
        $api_token = $request->api_token;


        $crm_expense_category = CRMExpensesCategories::all();
        $currency = explode(',', ApiHelper::getKeySetVal('other_supported_currency'));
        $paymentMethodList = PaymentMethods::all();

        $crmTaxGroup = CRMSettingTaxGroup::with('tax_info')->where('status', 1)->get();

        $taxTypeIds = [];

        if (!empty($crmTaxGroup)) {
            foreach ($crmTaxGroup as $taxGroup) {
                if (!empty($taxGroup->tax_info)) {
                    foreach ($taxGroup->tax_info as $taxInfo) {
                        $tax_type = CRMSettingTaxType::where('id', $taxInfo->tax_type_id)->first();
                        $taxInfo->tax_name = $tax_type->tax_name;

                        if (!in_array($taxInfo->tax_type_id, $taxTypeIds)) {
                            $taxTypeIds[] = $taxInfo->tax_type_id;
                        }
                    }
                }
            }
        }

        $folder = ApiHelper::db_folder($api_token);

        $file_url = Storage::url($folder . "/sales/transactions/");


        $appTransactions = AppTransactions::find($request->income_id);
        $customers = CRMCustomer::all();
        $accounts = AppAccounts::all();

        $res = [
            "crm_expense_category" => $crm_expense_category,
            "currency" => $currency,
            "TaxGroup" => $crmTaxGroup,
            "customers" => $customers,
            "accounts" => $accounts,
            "appTransaction" => $appTransactions,
            "file_url" => $file_url,
            'paymentMethodList' => $paymentMethodList

        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        // $invoice = new AppInvoices();
        // $invoice->invoice_date = $request->date;
        // $invoice->note = $request->note;
        // $invoice->status = 1;



        $appTransaction = AppTransactions::find($request->id);

        $appTransaction->trans_date = Carbon::createFromFormat('d-m-Y', $request->date)->format(' Y-m-d');
        $appTransaction->account_id = $request->account;
        $appTransaction->type = "income";
        $appTransaction->dr_cr = "dr";
        $appTransaction->amount = $request->amount;
        $appTransaction->payment_method_id = $request->payment_method_id;
        $appTransaction->payer_payee_id = $request->payer_payee_id;
        $appTransaction->reference = $request->reference;
        $appTransaction->note = $request->note;

        if ($request->hasFile('attachment')) {
            $image = $request->attachment;

            $times = time();
            $extension = $image->getClientOriginalExtension();
            $folder = ApiHelper::db_folder($api_token);

            $dir = $folder . "/sales/transactions/";

            $path = $image->storeAs($dir, $times . '.' . $extension);

            $appTransaction->attachment = $times . '.' . $extension;
        };

        $appTransaction->update();


        if ($request->has('recurring') && !empty($request->recurring)) {
            $appRepeatTransaction = AppRepeatTransactions::find($request->id);

            //    return ApiHelper::JSON_RESPONSE(true,  $date, 'SUCCESS_EXPENSE_UPDATE');

            //  $appRepeatTransaction->trans_date = Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d');
            if (!empty($appRepeatTransaction)) {
                $appRepeatTransaction->trans_date = Carbon::createFromFormat('d-m-Y', $request->date)->format('Y-m-d');
                $appRepeatTransaction->account_id = $request->account;
                $appRepeatTransaction->type = "income";
                $appRepeatTransaction->dr_cr = "dr";
                $appRepeatTransaction->amount = $request->amount;
                $appRepeatTransaction->payment_method_id = $request->payment_method_id;
                $appRepeatTransaction->payer_payee_id = $request->payer_payee_id;
                $appRepeatTransaction->reference = $request->reference;
                $appRepeatTransaction->note = $request->note;
                $appRepeatTransaction->update();
            }
        }



        return ApiHelper::JSON_RESPONSE(true, $appTransaction, 'SUCCESS_EXPENSE_UPDATE');
    }

    public function destroy(Request $request)
    {
        CRMExpenses::where('id', $request->id)->delete();

        return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_DELETE_EXPENSE');
    }

    public function calendar()
    {

        // $events = Holiday::all();


        // $res = [

        //     'events' => $events

        // ];


        $transactions = Transaction::where("company_id", company_id())
            ->where("type", "expense")
            ->orderBy("id", "desc")->get();
        return view('backend.accounting.expense.calendar', compact('transactions'));
    }
}
