<?php

namespace Modules\CRM\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Currency;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Modules\CRM\Models\CRMExpenses;
use Modules\CRM\Models\AccCategories;
use Modules\CRM\Models\CRMSettingTaxType;
use Modules\CRM\Models\CRMSettingTaxGroup;
use Modules\CRM\Models\AccTransactions;
use Modules\CRM\Models\CRMCustomer;
use ApiHelper;
use Carbon\Carbon;
use Modules\CRM\Models\AccAccounts;
use Illuminate\Support\Facades\Storage;
use App\Models\PaymentMethods;
use Modules\CRM\Models\AccRepeatTransactions;
use Modules\CRM\Models\AccInvoices;
use App\Models\Order;
use DateTime;
use Modules\CRM\Exports\TransactionExport;
use Maatwebsite\Excel\Facades\Excel;
use Maatwebsite\Excel\Excel as ExcelExcel;


class TransactionController extends Controller
{

    public $page = 'transaction';
    public $page_calendar = 'transaction_calendar';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    public function index(Request $request)
    {

        // Validate user page access
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? (int)$request->perPage : ApiHelper::perPageItem();
        $search = $request->search;
        $sortBY = $request->sortBy;
        $ASCTYPE = $request->orderBY;


        $data_query =  AccTransactions::with('Accounts');
        $customer = CRMCustomer::all();



        if ($request->start_date) {
            if ($request->start_date != NULL) {
                $myDateTime = DateTime::createFromFormat('Y-m-d', $request->start_date);
                $start_date = $myDateTime->format('Y-m-d');
                $data_query = $data_query->whereDate('txn_date', '>=', $start_date);
            }
        }
        /* Add End Date Filter  */
        if ($request->end_date) {
            if ($request->end_date != NULL) {
                $myDateTime = DateTime::createFromFormat('Y-m-d', $request->end_date);
                $end_date = $myDateTime->format('Y-m-d');

                $data_query = $data_query->whereDate('txn_date', '<=', $end_date);
            }
        }

        if ($request->txntype) {
            if ($request->txntype != NULL && $request->txntype != "all") {
                $data_query = $data_query->where("txn_type", $request->txntype);
            }
        }
        if ($request->paymethod) {
            if ($request->paymethod != NULL && $request->paymethod != "all") {
                $data_query = $data_query->where("payment_method_id", $request->paymethod);
            }
        }


        if (!empty($sortBY) && !empty($ASCTYPE)) {
            $data_query = $data_query->orderBy('txn_date', 'desc')->orderBy($sortBY, $ASCTYPE);
        } else {
            $data_query = $data_query->orderBy('txn_date', 'desc')->orderBy('id', 'DESC');
        }

        $skip = ($current_page == 1) ? 0 : (int)($current_page - 1) * $perPage;
        $user_count = $data_query->count();

        $data_list = $data_query->skip($skip)->take($perPage)->orderBy('txn_date', 'desc')->orderBy('id', 'DESC')->get();


        $dateFormat = ApiHelper::dateFormat();


        $res = [
            'app_transactions' => $data_list,
            'customer' => $customer,
            'current_page' => $current_page,
            'total_records' => $user_count,
            'total_page' => ceil((int)$user_count / (int)$perPage),
            'per_page' => $perPage,
            'date_format' => $dateFormat,
            'start_date' => $request->start_date,
            'end_date' => $request->end_date,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function create(Request $request)
    {

        $crm_expense_category = AccCategories::where('status', 1)->get();
        $currency = explode(',', ApiHelper::getKeySetVal('other_supported_currency'));
        $defaultCurrency = ApiHelper::getKeySetVal('default_currency');
        $SelectedTaxGroup = ApiHelper::getKeySetVal('tax_group');
        $crmTaxGroup = CRMSettingTaxGroup::with('tax_info')->where('status', 1)->get();
        $paymentMethodList = PaymentMethods::all();
        $invoices = AccInvoices::all();
        $orders = Order::all();

        $taxTypeIds = [];

        if (!empty($crmTaxGroup)) {
            foreach ($crmTaxGroup as $taxGroup) {
                if (!empty($taxGroup->tax_info)) {
                    foreach ($taxGroup->tax_info as $taxInfo) {
                        $tax_type = CRMSettingTaxType::where('id', $taxInfo->tax_type_id)->first();
                        $taxInfo->tax_name = $tax_type->tax_name;

                        if (!in_array($taxInfo->tax_type_id, $taxTypeIds)) {
                            $taxTypeIds[] = $taxInfo->tax_type_id;
                        }
                    }
                }
            }
        }



        $customers = CRMCustomer::all();
        $accounts = AccAccounts::where('status', 1)->get();
        $res = [
            "crm_expense_category" => $crm_expense_category,
            "currency" => $currency,
            "TaxGroup" => $crmTaxGroup,
            "customers" => $customers,
            "accounts" => $accounts,
            'defaultCurrency' => $defaultCurrency,
            'SelectedTaxGroup' => $SelectedTaxGroup,
            'paymentMethodList' => $paymentMethodList,
            'invoices' => $invoices,
            'orders' => $orders
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        if ($request->transaction_type == "income") {
            $dr_cr = "cr";
        } else {
            $dr_cr = "dr";
        }

        if ($request->radioInput == "customer") {
            $cust_radio = $request->customer;
        } elseif ($request->radioInput == "invoice") {
            $inv_radio = $request->invoice;
        } elseif ($request->radioInput == "order") {
            $ord_radio = $request->order;
        }


        $appTransaction = new AccTransactions();
        $appTransaction->account_id = $request->account;
        $appTransaction->txn_type = $request->transaction_type;
        $appTransaction->txn_category = $request->category;
        $appTransaction->txn_date = Carbon::createFromFormat('d-m-Y', $request->date)->format(' Y-m-d');
        $appTransaction->dr_cr = $dr_cr;
        $appTransaction->amount = $request->amount;
        $appTransaction->base_currency = $request->currency;
        $appTransaction->customer_id = $cust_radio ?? NULL;
        $appTransaction->invoice_id = $inv_radio ?? NULL;
        $appTransaction->order_id = $ord_radio ?? NULL;
        $appTransaction->base_amount = $request->baseAmount;
        $appTransaction->payment_method_id = $request->payment_mode;
        $appTransaction->reference = $request->reference;
        $appTransaction->note = $request->note;


        if ($request->hasFile('attachment')) {
            $image = $request->attachment;

            $times = time();
            $extension = $image->getClientOriginalExtension();
            $folder = ApiHelper::db_folder($api_token);

            $dir = $folder . "/sales/transactions/";

            $path = $image->storeAs($dir, $times . '.' . $extension);

            $appTransaction->attachment = $times . '.' . $extension;
        };

        $appTransaction->save();


        if ($request->has('recurring') && !empty($request->recurring)) {
            $appRepeatTransaction = new AccRepeatTransactions();
            $appRepeatTransaction->txn_id = $appTransaction->id;
            $appRepeatTransaction->account_id = $request->account;
            $appRepeatTransaction->txn_date = Carbon::createFromFormat('d-m-Y', $request->date)->format(' Y-m-d');
            $appRepeatTransaction->txn_type = $request->transaction_type;
            $appRepeatTransaction->dr_cr = $dr_cr;
            $appRepeatTransaction->amount = $request->amount;
            $appRepeatTransaction->customer_id = $request->customer;
            $appRepeatTransaction->payment_method_id = $request->payment_mode;
            $appRepeatTransaction->reference = $request->reference;
            $appRepeatTransaction->note = $request->note;
            $appRepeatTransaction->save();
        }

        $accounts = AccAccounts::where('id', $request->account)->first();
        if ($request->transaction_type == "income") {
            $closing_balance = $accounts->closing_balance + $request->amount;
        } else {
            $closing_balance = $accounts->closing_balance - $request->amount;
        }

        $accounts->update([
            "closing_balance" => $closing_balance,
        ]);


        return ApiHelper::JSON_RESPONSE(true, $appTransaction, 'SUCCESS_TRANSACTION_ADD');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
        $api_token = $request->api_token;


        $crm_expense_category = AccCategories::where('status', 1)->get();
        $currency = explode(',', ApiHelper::getKeySetVal('other_supported_currency'));
        $paymentMethodList = PaymentMethods::all();

        $crmTaxGroup = CRMSettingTaxGroup::with('tax_info')->where('status', 1)->get();

        $taxTypeIds = [];

        if (!empty($crmTaxGroup)) {
            foreach ($crmTaxGroup as $taxGroup) {
                if (!empty($taxGroup->tax_info)) {
                    foreach ($taxGroup->tax_info as $taxInfo) {
                        $tax_type = CRMSettingTaxType::where('id', $taxInfo->tax_type_id)->first();
                        $taxInfo->tax_name = $tax_type->tax_name;

                        if (!in_array($taxInfo->tax_type_id, $taxTypeIds)) {
                            $taxTypeIds[] = $taxInfo->tax_type_id;
                        }
                    }
                }
            }
        }

        $folder = ApiHelper::db_folder($api_token);

        $file_url = Storage::url($folder . "/sales/transactions/");


        $appTransactions = AccTransactions::find($request->expense_id);
        $customers = CRMCustomer::all();
        $accounts = AccAccounts::where('status', 1)->get();
        $invoices = AccInvoices::all();
        $orders = Order::all();

        $res = [
            "crm_expense_category" => $crm_expense_category,
            "currency" => $currency,
            "TaxGroup" => $crmTaxGroup,
            "customers" => $customers,
            "accounts" => $accounts,
            "appTransaction" => $appTransactions,
            "file_url" => $file_url,
            'paymentMethodList' => $paymentMethodList,
            'invoices' => $invoices,
            'orders' => $orders

        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        if ($request->transaction_type == "income") {
            $dr_cr = "cr";
        } else {
            $dr_cr = "dr";
        }

        if ($request->radioInput == "customer") {
            $cust_radio = $request->customer;
        } elseif ($request->radioInput == "invoice") {
            $inv_radio = $request->invoice;
        } elseif ($request->radioInput == "order") {
            $ord_radio = $request->order;
        }

        $txn = AccTransactions::find($request->id);

        $amount = $request->amount - $txn->amount;

        $accounts = AccAccounts::where('id', $request->account)->first();
        if ($request->transaction_type == "income") {
            $closing_balance = $accounts->closing_balance + $amount;
        } else {
            $closing_balance = $accounts->closing_balance - $amount;
        }

        $accounts->update([
            "closing_balance" => $closing_balance,
        ]);




        $appTransaction = AccTransactions::find($request->id);
        $appTransaction->account_id = $request->account;
        $appTransaction->txn_type = $request->transaction_type;
        $appTransaction->txn_category = $request->category;
        $appTransaction->txn_date = Carbon::createFromFormat('d-m-Y', $request->date)->format(' Y-m-d');
        $appTransaction->dr_cr = $dr_cr;
        $appTransaction->amount = $request->amount;
        $appTransaction->customer_id = $cust_radio ?? NULL;
        $appTransaction->invoice_id = $inv_radio ?? NULL;
        $appTransaction->order_id = $ord_radio ?? NULL;
        $appTransaction->base_amount = $request->baseAmount;
        $appTransaction->payment_method_id = $request->payment_mode;
        $appTransaction->reference = $request->reference;
        $appTransaction->note = $request->note;




        if ($request->has('recurring') && !empty($request->recurring)) {
            $appRepeatTransaction = new AccRepeatTransactions();
            $appRepeatTransaction->txn_id = $appTransaction->id;
            $appRepeatTransaction->account_id = $request->account;
            $appRepeatTransaction->txn_date = Carbon::createFromFormat('d-m-Y', $request->date)->format(' Y-m-d');
            $appRepeatTransaction->txn_type = $request->transaction_type;
            $appRepeatTransaction->dr_cr = $dr_cr;
            $appRepeatTransaction->amount = $request->amount;
            $appRepeatTransaction->customer_id = $request->customer;
            $appRepeatTransaction->payment_method_id = $request->payment_mode;
            $appRepeatTransaction->reference = $request->reference;
            $appRepeatTransaction->note = $request->note;
            $appRepeatTransaction->save();
        }




        if ($request->hasFile('attachment')) {
            $image = $request->attachment;

            $times = time();
            $extension = $image->getClientOriginalExtension();
            $folder = ApiHelper::db_folder($api_token);

            $dir = $folder . "/sales/transactions/";

            $path = $image->storeAs($dir, $times . '.' . $extension);

            $appTransaction->attachment = $times . '.' . $extension;
        };

        $appTransaction->update();





        return ApiHelper::JSON_RESPONSE(true, $appTransaction, 'SUCCESS_TRANSACTION_UPDATE');
    }

    public function destroy(Request $request)
    {
        AccTransactions::where('id', $request->id)->delete();

        return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_DELETE_TRANSACTION');
    }

    public function calendar(Request $request)
    {
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page_calendar, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        $transactions = AccTransactions::orderBy("id", "desc")->get();

        $res = [
            'transactions' => $transactions
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function export(Request $request)
    {
        $filters = [
            'txntype' => $request->txntype,
            'paymethod' => $request->paymethod,
            'startDate' => $request->startDate,
            'endDate' => $request->endDate,
        ];


        $data = [
            'company' => ''
        ];

        $date = Carbon::now(); // Current date and time

        $formattedDate = $date->format('Ymd');

        $file_name = "Transaction " . $formattedDate . ".xlsx";

        $data = Excel::store(new TransactionExport($filters), $file_name);

        $url = Storage::path($file_name);

        return ApiHelper::JSON_RESPONSE(true, $url, 'hii');
    }
}
