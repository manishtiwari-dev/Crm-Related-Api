<?php

namespace Modules\CRM\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Modules\CRM\Models\AccInvoices;
use Modules\CRM\Models\AccInvoicesItem;
use Modules\CRM\Models\AccInvoiceItemTaxes;
use Illuminate\Support\Str;
use ApiHelper;
use Modules\CRM\Models\CRMSettingTaxGroup;
use Modules\CRM\Models\CRMCustomer;
use Modules\CRM\Models\CRMCustomerAddress;
use App\Models\Currency;
use App\Models\Country;
use Modules\CRM\Models\CRMSettingTaxType;
use Modules\CRM\Models\CRMSettingPaymentTerms;
use App\Models\User;
use Modules\CRM\Models\CRMLead;
use Modules\CRM\Models\CRMLeadFollowUp;
use Modules\CRM\Models\CRMQuotation;
use Modules\CRM\Models\CRMSettingTaxPercentage;
use Modules\CRM\Models\QuoteReminderHistory;
use Modules\Ecommerce\Models\ProductsOptionsValues;
use Modules\CRM\Models\CRMQuotationItem;
use Carbon\Carbon;
use DateTime;
use Modules\Ecommerce\Models\Product;

class InvoiceController extends Controller
{

    public $page = 'invoice';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    public function index(Request $request)
    {

        // Validate user page access
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? (int)$request->perPage : ApiHelper::perPageItem();
        $search = $request->search;
        $sortBY = $request->sortBy;
        $ASCTYPE = $request->orderBY;


        $data_query = AccInvoices::with('customer');


        // if (!empty($search))
        $data_query = $data_query->where("invoice_number", "LIKE", "%{$search}%");

        if ($request->has('start_date')) {
            if ($request->start_date != NULL) {
                $myDateTime = DateTime::createFromFormat('Y-m-d', $request->start_date);
                $start_date = $myDateTime->format('Y-m-d');
                $data_query = $data_query->whereDate('created_at', '>=', $start_date);
            }
        }

        /* Add End Date Filter  */
        if ($request->has('end_date')) {
            if ($request->end_date != NULL) {
                $myDateTime = DateTime::createFromFormat('Y-m-d', $request->end_date);
                $end_date = $myDateTime->format('Y-m-d');

                $data_query = $data_query->whereDate('created_at', '<=', $end_date);
            }
        }

        if ($request->has('client')) {
            if ($request->client != NULL) {
                $data_query = $data_query->where("customer_id", $request->client);
            }
        }

        if ($request->has('status')) {
            if ($request->status != NULL) {
                $data_query = $data_query->where("status", $request->status);
            }
        }


        if (!empty($sortBY) && !empty($ASCTYPE)) {
            $data_query = $data_query->orderBy($sortBY, $ASCTYPE);
        } else {
            $data_query = $data_query->orderBy('id', 'DESC');
        }

        $skip = ($current_page == 1) ? 0 : (int)($current_page - 1) * $perPage;
        $user_count = $data_query->count();

        $data_list = $data_query->skip($skip)->take($perPage)->orderBy('id', 'DESC')->get();


        $dateFormat = ApiHelper::dateFormat();

        $customer = CRMCustomer::where('status', 1)->get();

        $res = [
            "app_invoice_list" => $data_list,
            "customer" => $customer,
            'current_page' => $current_page,
            'total_records' => $user_count,
            'total_page' => ceil((int)$user_count / (int)$perPage),
            'per_page' => $perPage,
            'date_format' => $dateFormat,
            'start_date' => $request->start_date,
            'end_date' => $request->end_date,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }



    public function create(Request $request)
    {


        $inv_no_digit = ApiHelper::getKeySetVal('invoice_number_digit');

        // $invoiceId = $this->GenerateAndCheck('AccInvoices', 'invoice_number', [1, 7]);
        $invoiceId = ApiHelper::generate_invoice_number('alpha_numeric', $inv_no_digit);

        $customer = CRMCustomer::where('status', 1)->get();

        $inv_prefix = ApiHelper::getKeySetVal('invoice_prefix');
        $inv_due_after = ApiHelper::getKeySetVal('invoice_due_after');



        foreach ($customer as $crmCustomer) {
            if (!empty($crmCustomer)) {
                $crmCustomer->setRelation('crm_customer_address', $crmCustomer->crm_customer_address()->where(['status' => 1, 'address_type' => 2])->get());
            }

            $address_list = $crmCustomer->crm_customer_address->map(function ($data) {
                $data->country_name = Country::where('countries_id', $data->countries_id)->first()->countries_name;
                return $data;
            });
        }

        $currency = explode(',', ApiHelper::getKeySetVal('other_supported_currency'));
        $defaultCurrency = ApiHelper::getKeySetVal('default_currency');

        $paymentterms = CRMSettingPaymentTerms::all();
        $country = Country::all();


        $crmTaxGroup = CRMSettingTaxGroup::with('tax_info')->where('status', 1)->get();

        $taxTypeIds = [];

        if (!empty($crmTaxGroup)) {
            foreach ($crmTaxGroup as $taxGroup) {
                if (!empty($taxGroup->tax_info)) {
                    foreach ($taxGroup->tax_info as $taxInfo) {
                        $tax_type = CRMSettingTaxType::where('id', $taxInfo->tax_type_id)->first();
                        $taxInfo->tax_name = $tax_type->tax_name;

                        if (!in_array($taxInfo->tax_type_id, $taxTypeIds)) {
                            $taxTypeIds[] = $taxInfo->tax_type_id;
                        }
                    }
                }
            }
        }


        $res = [
            'app_invoice' => $invoiceId,
            'customers' => $customer,
            'currency' => $currency,
            'country' => $country,
            'paymentterms' => $paymentterms,
            'TaxGroup' => $crmTaxGroup,
            'taxTypeIds' => $taxTypeIds,
            'defaultCurrency' => $defaultCurrency,
            'inv_prefix' => $inv_prefix,
            'inv_due_after' => $inv_due_after
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        // Validate user page access
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');



        $invoice = new AccInvoices();
        $invoice->invoice_number = $request->invoice_number;
        $invoice->customer_id = $request->customer_id;
        $invoice->address_id = $request->billing_address_id;
        $invoice->invoice_date = Carbon::createFromFormat('d/m/Y', $request->invoice_date)->format(' Y-m-d');
        $invoice->due_date = Carbon::createFromFormat('d/m/Y', $request->due_date)->format(' Y-m-d');
        $invoice->currency = $request->currency;
        $invoice->subtotal = $request->subtotal;
        $invoice->shipping_cost = $request->shipping_cost;
        $invoice->total_tax = $request->total_tax;
        $invoice->discount = $request->discount;
        $invoice->final_cost = $request->final_cost;
        $invoice->note = $request->note;
        $invoice->status  = 'pending';
        $invoice->save();

        if ($invoice) {

            $item_name = $request->item_name;
            $quantity = $request->quantity;
            $unit_price = $request->unit_price;
            $item_discount = $request->item_discount;
            $item_id = $request->item_id;
            $tax_group_id = $request->tax_group_id;
            $item_cost = $request->item_cost;
            $sac_code = $request->sac_code;
            $attributeArray = [];

            if (!empty($request->item_attributes)) {
                foreach ($request->item_attributes as $attributes) {
                    $attributeArray[] = $attributes;
                }
            }


            foreach ($item_name as $key => $value) {

                $cal_qty = $quantity[$key] ?? 1;
                $cal_unit_price = $unit_price[$key] ?? 0;
                $cal_discount = $item_discount[$key] ?? 0;
                $tax_percetages = CRMSettingTaxPercentage::where('tax_group_id', $tax_group_id[$key])->sum('tax_percent');

                $tax_amount = ((($cal_qty * $cal_unit_price) - $cal_discount) * $tax_percetages) / 100;


                $acc_invoice_id = AccInvoicesItem::create([
                    "invoice_id" => $invoice->id,
                    "item_id" => $item_id[$key] ?? 0,
                    "item_name" =>  $item_name[$key] ?? 0,
                    "sac_code" =>  $sac_code[$key] ?? '',
                    "quantity" =>  $quantity[$key] ?? 1,
                    "unit_price" => $unit_price[$key] ?? 0,
                    "discount" =>  $item_discount[$key] ?? 0,
                    "item_cost" => $item_cost[$key]  ?? 0,
                    "attributes" => sizeof($attributeArray) > 0 ? json_encode($attributeArray[$key]) : NULL,
                    "tax_group_id" => $tax_group_id[$key] ?? 0,
                    "tax_amount" =>  $tax_amount,
                    "updated_at" => date("Y-m-d"),
                ]);
            }
        }



        return ApiHelper::JSON_RESPONSE(true, $invoice, 'SUCCESS_INVOICE_ADD');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        $app_invoice = AccInvoices::with('crm_invoice_item')->find($request->invoice_id);

        $app_invoice->currency_symbol = Currency::where('currencies_code', $app_invoice->currency)->first()->symbol_left;

        if (!empty($app_invoice)) {
            $data_list = $app_invoice->crm_invoice_item->map(function ($data) use ($request) {
                $data->tax_group_name = ApiHelper::getGroupName($data->tax_group_id);
                if (!empty($data->item_id)) {
                    $request->request->add(['product_id' => $data->item_id, 'language' => 1]);
                    $product_data = $this->SearchItemDetail($request)->getData()->data; // Call the function for Product detail with price

                    $data->product_data = $product_data;
                }
                return $data;
            });
        }


        $app_invo_item = AccInvoicesItem::where("invoice_id", $app_invoice->id)->first();

        $customer = CRMCustomer::where('status', 1)->get();

        foreach ($customer as $crmCustomer) {
            if (!empty($crmCustomer)) {
                $crmCustomer->setRelation('crm_customer_address', $crmCustomer->crm_customer_address()->where(['status' => 1, 'address_type' => 2])->get());
            }

            $address_list = $crmCustomer->crm_customer_address->map(function ($data) {
                $data->country_name = Country::where('countries_id', $data->countries_id)->first()->countries_name;
                return $data;
            });
        }

        $defaultCurrency = ApiHelper::getKeySetVal('default_currency');
        $currency = explode(',', ApiHelper::getKeySetVal('other_supported_currency'));

        $crmTaxGroup = CRMSettingTaxGroup::with('tax_info')->where('status', 1)->get();

        $taxTypeIds = [];

        if (!empty($crmTaxGroup)) {
            foreach ($crmTaxGroup as $taxGroup) {
                if (!empty($taxGroup->tax_info)) {
                    foreach ($taxGroup->tax_info as $taxInfo) {
                        $tax_type = CRMSettingTaxType::where('id', $taxInfo->tax_type_id)->first();
                        $taxInfo->tax_name = $tax_type->tax_name;

                        if (!in_array($taxInfo->tax_type_id, $taxTypeIds)) {
                            $taxTypeIds[] = $taxInfo->tax_type_id;
                        }
                    }
                }
            }
        }

        $invoice_data = [];

        $invoice_data['invoice_logo'] = ApiHelper::getKeySetVal('invoice_logo');
        $invoice_data['invoice_note'] = ApiHelper::getKeySetVal('invoice_note');
        $invoice_data['invoice_prefix'] = ApiHelper::getKeySetVal('invoice_prefix');

        $invoice_data['invoice_biller_address'] = !empty(ApiHelper::getKeySetVal('invoice_biller_address')) ? ApiHelper::getKeySetVal('invoice_biller_address') : ApiHelper::getKeyVal('contact_address')
            . ' ,' . ApiHelper::getKeyVal('contact_city') . ' ,' . ApiHelper::getKeyVal('contact_state') . ' ,' . ApiHelper::getKeyVal('contact_country') . ' ,' . ApiHelper::getKeyVal('contact_zipcode');
        $invoice_data['business_email'] = ApiHelper::getKeySetVal('business_email');
        $invoice_data['contact_phone'] = ApiHelper::getKeyVal('contact_phone');
        $invoice_data['company_name'] = !empty(ApiHelper::getKeySetVal('business_name')) ? ApiHelper::getKeySetVal('business_name') : ApiHelper::getKeyVal('company_name');

        $customer_addrs = CRMCustomerAddress::where('address_id', $app_invoice->billing_address_id)->first();
        if (!empty($customer_addrs))
            $customer_addrs['country_name'] = Country::where('countries_id', $customer_addrs->countries_id)->first()->countries_name;

        $invoice_data['customer_address'] = $customer_addrs;


        $paymentterms = CRMSettingPaymentTerms::all();



        $res = [
            'app_invoice' => $app_invoice,
            'app_invo_item' => $app_invo_item,
            'customer' => $customer,
            'currency' => $currency,
            'TaxGroup' => $crmTaxGroup,
            'taxTypeIds' => $taxTypeIds,
            'defaultCurrency' => $defaultCurrency,
            'paymentterms'  => $paymentterms,
            'invoice_data' => $invoice_data,
            'website_url' => ApiHelper::getKeyVal('website_url'),
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        try {
            $invoice = AccInvoices::find($request->invoice_id);
            $invoice->invoice_number = $request->invoice_number;
            $invoice->customer_id = $request->customer_id;
            $invoice->address_id = $request->billing_address_id;
            $invoice->invoice_date = Carbon::createFromFormat('d/m/Y', $request->invoice_date)->format(' Y-m-d');
            $invoice->due_date = Carbon::createFromFormat('d/m/Y', $request->due_date)->format(' Y-m-d');
            $invoice->currency = $request->currency;
            $invoice->subtotal = $request->subtotal;
            $invoice->shipping_cost = $request->shipping_cost;
            $invoice->total_tax = $request->total_tax;
            $invoice->discount = $request->discount;
            $invoice->final_cost = $request->final_cost;
            $invoice->note = $request->note;
            $invoice->status  = 'pending';
            $invoice->update();

            if ($invoice) {

                $item_name = $request->item_name;
                $quantity = $request->quantity;
                $unit_price = $request->unit_price;
                $item_discount = $request->item_discount;
                $item_id = $request->item_id;
                $tax_group_id = $request->tax_group_id;
                $item_cost = $request->item_cost;
                $sac_code = $request->sac_code;
                $attributeArray = [];

                if (!empty($request->item_attributes)) {
                    foreach ($request->item_attributes as $attributes) {
                        $attributeArray[] = $attributes;
                    }
                }


                AccInvoicesItem::where('invoice_id', $request->invoice_id)->delete();

                if ($item_name) {
                    foreach ($item_name as $key => $value) {

                        $cal_qty = $quantity[$key] ?? 1;
                        $cal_unit_price = $unit_price[$key] ?? 0;
                        $cal_discount = $item_discount[$key] ?? 0;
                        $tax_percetages = CRMSettingTaxPercentage::where('tax_group_id', $tax_group_id[$key])->sum('tax_percent');

                        $tax_amount = ((($cal_qty * $cal_unit_price) - $cal_discount) * $tax_percetages) / 100;


                        $acc_invoice_id = AccInvoicesItem::create([
                            "invoice_id" => $invoice->id,
                            "item_id" => $item_id[$key] ?? 0,
                            "item_name" =>  $item_name[$key] ?? 0,
                            "sac_code" =>  $sac_code[$key] ?? '',
                            "quantity" =>  $quantity[$key] ?? 1,
                            "unit_price" => $unit_price[$key] ?? 0,
                            "discount" =>  $item_discount[$key] ?? 0,
                            "item_cost" => $item_cost[$key]  ?? 0,
                            // "attributes" => sizeof($attributeArray) > 0 ? json_encode($attributeArray[$key]) : '', 
                            "tax_group_id" => $tax_group_id[$key] ?? 0,
                            "tax_amount" =>  $tax_amount,
                            "updated_at" => date("Y-m-d"),
                        ]);
                    }
                }
            }



            return ApiHelper::JSON_RESPONSE(true, $invoice, 'SUCCESS_INVOICE_UPDATE');
        } catch (Exception $e) {
            return ApiHelper::JSON_RESPONSE(false, $e->getMessage(), 'ERROR_INVOICE_UPDATE');
        }
    }

    public function destroy(Request $request)
    {
        CRMExpenses::where('id', $request->id)->delete();

        return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_DELETE_EXPENSE');
    }

    public function GenerateAndCheck($model, $column_name, $sizeArray)
    {


        $inv_no_digit = ApiHelper::getKeySetVal('invoice_number_digit');

        $generatedNumber = ApiHelper::generate_random_token('alphabet', $sizeArray[0]) . ApiHelper::generate_random_token('alpha_numeric', $sizeArray[1]);
        $modelpath = str_replace('"', "", 'Modules\CRM\Models' . '\\' . $model);
        $availabel = $modelpath::where($column_name, $generatedNumber)->first();
        if (!empty($availabel)) {
            $this->GenerateAndCheck($model, $column_name, $sizeArray);
        } else {
            return $generatedNumber;
        }
    }

    public function SearchItemDetail(Request $request)
    {
        $language = $request->language;
        $product_id = $request->product_id;

        $product =  Product::with('productdescription', 'productAttribute')->where('product_id', $product_id)->first();

        if (!empty($product)) {

            $pr = $product->productdescription()->where('languages_id', $language)->first();
            $product->products_name = ($pr == null) ? '' : $pr->products_name;
            $product->products_description = ($pr == null) ? '' : $pr->products_description;

            // relate with attach attributes
            $attributes = $product->productAttribute()->with('productOptions')->groupBy('options_id')->get();

            if (!empty($attributes)) {
                $attributes->map(function ($option) use ($product) {
                    $option->option_name = $option->productOptions->products_options_name;
                    $option->option_value_list = $product->productAttribute()->with('productOptionsValue')->where('options_id', $option->options_id)->get();
                    return $option;
                });
            }
            $product->productAttribute = $attributes;

            $product->attribute_sale_price = Null;

            $resArray = Product::GetSalePrice($product->product_id);

            $product->sale_price = $resArray['sale_price'];
            $product->bulkPrice = $resArray['bulkPrice'];

            $product_qty = $resArray['qty'] ?? 1;

            $attribute_array = [];

            $itemAttribute = $product->productAttribute()->with('productOptions')->get();

            if (!empty($itemAttribute)) {
                foreach ($itemAttribute as $key => $attribute) {
                    $attribute_array[$key]['options_id'] = $attribute->options_id;
                    $attribute_array[$key]['options_values_id'] = $attribute->options_values_id;
                }

                $request['attribute_array'] = $attribute_array;
                $request['OrderdQty'] = 1;

                // $product->attribute_sale_price = $this->attributeToprice($request)->getData()->final_price;
                // $product->discount = $this->attributeToprice($request)->getData()->totalDiscountPrice;

                $product->product_qty = $product_qty;
            }

            return ApiHelper::JSON_RESPONSE(true, $product, 'SUCCESS');
        } else {
            return ApiHelper::JSON_RESPONSE(true, [], 'ERROR');
        }
    }

    public function mailSenderHelper($Quote_data)
    {
        $customer_data = CRMCustomer::find($Quote_data->customer_id);

        $dt = Carbon::now();
        $today_date = $dt->toDateString();

        $mail_data = [
            'sender_name' => 'Sender Name',
            'sender_email' => 'senderemail@gmail.com',
            'subject' => "Quotation Reminder",
            'content' => "Please Pay your payment",
            // 'unsubscription_url' => url()->full(),
            'customer_data' => $customer_data,
            'web_base_url' => ApiHelper::getKeyVal('website_url'),
        ];

        try {
            QuoteReminderHistory::create([
                'quote_id' => $Quote_data->quotation_id,
                'sent_at' => $today_date,
            ]);
            QuoteReminderJob::dispatch($mail_data)->delay(now()->addSeconds(value: 5));
        } catch (Exception $e) {
            echo ($e->getMessage());
        }
    }

    public function InvoiceDetailsPDF(Request $request)
    {
        $api_token = $request->api_token;

        $response = AccInvoices::with('crm_invoice_item', 'customer')->where('invoice_number', $request->invoice_no)->first();
        $response->currency_symbol = Currency::where('currencies_code', $response->currency)->first()->symbol_left;
        if (!empty($response->crm_quotation_address))
            $response->crm_quotation_address->country_name = Country::where('countries_id', $response->crm_quotation_address->countries_id)->first()->countries_name;

        if (!empty($response)) {
            $data_list = $response->crm_invoice_item->map(function ($data) use ($request) {
                $data->tax_group_name = ApiHelper::getGroupName($data->tax_group_id);
                if (!empty($data->item_id)) {
                    $request->request->add(['product_id' => $data->item_id, 'language' => 1]);
                    $product_data = $this->SearchItemDetail($request)->getData()->data; // Call the function for Product detail with price

                    $data->product_data = $product_data;
                }
                return $data;
            });
        }


        // Invoice Sender Data Work Here  

        $invoice_data = [];

        $invoice_data['invoice_logo'] = ApiHelper::getFullImageUrl(ApiHelper::getKeySetVal('invoice_logo'));
        $invoice_data['invoice_note'] = ApiHelper::getKeySetVal('invoice_note');
        $invoice_data['invoice_prefix'] = ApiHelper::getKeySetVal('invoice_prefix');
        $invoice_data['term_condition'] = ApiHelper::getKeySetVal('invoice_term_and_condition');
        $invoice_data['invoice_note'] = ApiHelper::getKeySetVal('invoice_note');
        $invoice_data['bank_account'] = ApiHelper::getKeySetVal('invoice_bank_account');

        $invoice_data['invoice_biller_address'] = !empty(ApiHelper::getKeySetVal('invoice_biller_address')) ? ApiHelper::getKeySetVal('invoice_biller_address') : ApiHelper::getKeyVal('contact_address')
            . ' ,' . ApiHelper::getKeyVal('contact_city') . ' ,' . ApiHelper::getKeyVal('contact_state') . ' ,' . ApiHelper::getKeyVal('contact_country') . ' ,' . ApiHelper::getKeyVal('contact_zipcode');
        $invoice_data['business_email'] = ApiHelper::getKeySetVal('business_email');
        $invoice_data['contact_phone'] = ApiHelper::getKeyVal('contact_phone');
        $invoice_data['company_name'] = !empty(ApiHelper::getKeySetVal('business_name')) ? ApiHelper::getKeySetVal('business_name') : ApiHelper::getKeyVal('company_name');


        $res = [
            'quote_detail' => $response,
            'invoice_data' => $invoice_data,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }


    public function changeStatus(Request $request)
    {
        $invoiceId = $request->invoiceId;
        $statusId = $request->statusId;

        if (empty($statusId) || empty($invoiceId))
            return ApiHelper::JSON_RESPONSE(false, '', 'SOME_FIELD_MISSING');

        $quote = AccInvoices::find($invoiceId);
        $quote->status = $statusId;
        $quote->save();

        if ($quote)
            return ApiHelper::JSON_RESPONSE(true, $quote, 'SUCCESS_STATUS_UPDATE');
        else
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_STATUS_UPDATE');
    }


    public function changeDate(Request $request)
    {

        $inv_due_after = ApiHelper::getKeySetVal('invoice_due_after');

        $date = Carbon::createFromFormat('d/m/Y', $request->invoice_date)->addDays($inv_due_after)->format('d/m/Y');



        return ApiHelper::JSON_RESPONSE(true, $date, 'SUCCESS_STATUS_UPDATE');
    }
}
