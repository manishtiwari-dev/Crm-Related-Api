<?php

namespace Modules\CRM\Http\Controllers;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use ApiHelper;
use Modules\CRM\Models\CRMLeadContact;

class CRMLeadContactController extends Controller
{

    public $page = 'leadcontact';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    public function index(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

        // if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageview))
        //     return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');



        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? $request->perPage : 10;
        $search = $request->search;
        $sortBY = $request->sortBy;
        $ASCTYPE = $request->orderBY;
        
        $data_query = CRMLeadContact::query();
      
        if(!empty($search))
        $data_query = $data_query->where("contact_name","LIKE", "%{$search}%");

        /* order by sorting */
        if (!empty($sortBY) && !empty($ASCTYPE)) {
            $data_query = $data_query->orderBy($sortBY, $ASCTYPE);
        } else {
            $data_query = $data_query->orderBy('lead_contact_id', 'ASC');
        }

        $skip = ($current_page == 1) ? 0 : (int)($current_page - 1) * $perPage;
        $user_count = $data_query->count();

        $data_list = $data_query->skip($skip)->take($perPage)->get();

        $data_list = $data_list->map(function($data)   {
            $data->status = ($data->status == 1) ? "active":"deactive";     
            return $data;
        });

        $res = [
            'data'=>$data_list,
            'current_page'=>$current_page,
            'total_records'=>$user_count,
            'total_page'=>ceil((int)$user_count/(int)$perPage),
            'per_page'=>$perPage
        ];

        return ApiHelper::JSON_RESPONSE(true,$res, '');
    }

    public function create()
    {
     //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

        // if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
        //     return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');

        //validation check 
        $rules = [
        'lead_id'=> 'required',
        'contact_name'=>'required|string',
        'contact_email'=>'required|string',
        ];
        $validator = Validator::make($request->all(), $rules);
        
        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false,'', $validator->messages());

            $data=$request->except(['api_token']);
        $prdopval = CRMLeadContact::create( $data);

        if ($prdopval) {
            return ApiHelper::JSON_RESPONSE(true, $prdopval, 'SUCCESS_CONTACT_ADD');
        } else {
            return ApiHelper::JSON_RESPONSE(false,'', 'ERROR_CONTACT_ADD');
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
        $response = CRMLeadContact::find($request->lead_contact_id);
        return ApiHelper::JSON_RESPONSE(true, $response,'');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        
        // if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
        //     return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');

        //validation check 
        $rules = [
            'lead_id'=> 'required',
            'contact_name'=>'required|string',
            'contact_email'=>'required|string',
            ];
            $validator = Validator::make($request->all(), $rules);

        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false,'', $validator->messages());

            $data=$request->except(['api_token','lead_contact_id']);
            $prdopval = CRMLeadContact::where('lead_contact_id',$request->lead_contact_id)
              ->update($data);

        
        if ($prdopval) {
            return ApiHelper::JSON_RESPONSE(true, $prdopval,'SUCCESS_CONTACT_UPDATE');
        } else {
            return ApiHelper::JSON_RESPONSE(false,'', 'ERROR_CONTACT_UPDATE');
        }
    }


}
