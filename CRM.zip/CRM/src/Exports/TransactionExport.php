<?php

namespace Modules\CRM\Exports;

use Modules\CRM\Models\AccTransactions;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Events\AfterSheet;
use Maatwebsite\Excel\Events\BeforeExport;
use Carbon\Carbon;


class TransactionExport implements FromCollection, WithHeadings, ShouldAutoSize
{
    use Exportable;

    protected $filters;
    public function __construct(array $filters)
    {
        $this->filters = $filters; 
    }

    public function collection()
    {

        $acc_transaction = config('dbtable.acc_transactions'); 
        $accounts =config('dbtable.acc_accounts');  
        $application_status =config('dbtable.rec_application_status'); 



        // Fetching All Job Applications

        // $jobApplications = AccTransactions::selectRaw('DATE(created_at) as date,id, txn_type,reference,dr_cr,amount');
            
        $jobApplications = AccTransactions::select( 
            ''.$acc_transaction.'.txn_date', 
            ''.$acc_transaction.'.txn_type', 
            ''.$accounts.'.account_title',
            ''.$accounts.'.account_number',
            ''.$acc_transaction.'.reference',
            ''.$acc_transaction.'.dr_cr', 
            ''.$acc_transaction.'.amount',
            ''.$acc_transaction.'.note',
        )->leftJoin(''.$accounts.'', ''.$accounts.'.id', '=', ''.$acc_transaction.'.account_id')->orderBy($acc_transaction.'.id', 'desc');

            
        if ($this->filters['txntype'] != 'all' && $this->filters['txntype'] != '') {
            $jobApplications = $jobApplications->where(''.$acc_transaction.'.txn_type', $this->filters['txntype']);
        }

        // Filter  By Location
        if ($this->filters['paymethod'] != 'all' && $this->filters['paymethod'] != '') {
            $jobApplications = $jobApplications->where(''.$acc_transaction.'.payment_method_id', $this->filters['paymethod']);
        }
  

        // Filter  By StartDate of job
        if ($this->filters['startDate'] != 'all' && $this->filters['startDate'] != null && $this->filters['startDate'] != '' && $this->filters['startDate'] != 0) {
            $startDate = $this->filters['startDate'];
            $jobApplications = $jobApplications->whereDate(''.$acc_transaction.'.txn_date', '>=', "$startDate");
        }

        // Filter  By EndDate of job
        if ($this->filters['endDate'] != 'all' && $this->filters['endDate'] != null && $this->filters['endDate'] != '' && $this->filters['endDate'] != 0) {
            $endDate = $this->filters['endDate'];

            $jobApplications = $jobApplications->whereDate(''.$acc_transaction.'.txn_date', '<=', "$endDate");
        }

        // $jobApplications->map(function ($item, $key) {
        //     $item->id = $key + 1; 
        // });

    
        $jobApplications = $jobApplications->get();
    
    
        return $jobApplications;


    }

 

    public function headings(): array
    {
        return ['Txn Date', 'Txn Type', 'Account Name','Account No,' ,'Reference' , 'CR/DR' ,'Amount','Note'];
    }

    
}
